/*
import React, { createContext, useContext, useState } from 'react';

const CartContext = createContext();

export function CartProvider({ children }) {
  const [cartItems, setCartItems] = useState([]);

  function addToCart(product) {
    setCartItems((currentItems) => {
      const existing = currentItems.find(
        (item) => String(item.id) === String(product.id)
      );

      if (existing) {
        return currentItems.map((item) =>
          String(item.id) === String(product.id)
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }

      return [...currentItems, { ...product, quantity: 1 }];
    });
  }

  function increaseQuantity(id) {
    setCartItems((items) =>
      items.map((item) =>
        String(item.id) === String(id)
          ? { ...item, quantity: item.quantity + 1 }
          : item
      )
    );
  }

  function decreaseQuantity(id) {
    setCartItems((items) =>
      items
        .map((item) =>
          String(item.id) === String(id)
            ? { ...item, quantity: item.quantity - 1 }
            : item
        )
        .filter((item) => item.quantity > 0)
    );
  }

  function removeFromCart(id) {
    setCartItems((items) =>
      items.filter((item) => String(item.id) !== String(id))
    );
  }

  function clearCart() {
    setCartItems([]);
  }

  return (
    <CartContext.Provider
      value={{
        cartItems,
        addToCart,
        increaseQuantity,
        decreaseQuantity,
        removeFromCart,
        clearCart,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  return useContext(CartContext);
}
*/

import React, { createContext, useContext, useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const CART_KEY = 'cart:items';

const CartContext = createContext();

export function CartProvider({ children }) {
  const [cartItems, setCartItems] = useState([]);
  const [loaded, setLoaded] = useState(false);

  // Restore the saved cart when the app starts
  useEffect(() => {
    async function loadCart() {
      try {
        const raw = await AsyncStorage.getItem(CART_KEY);
        if (raw) {
          setCartItems(JSON.parse(raw));
        }
      } catch (error) {
        // If reading fails we simply start with an empty cart
      } finally {
        setLoaded(true);
      }
    }
    loadCart();
  }, []);

  // Save the cart every time it changes (only after the first load finished)
  useEffect(() => {
    if (!loaded) return;
    AsyncStorage.setItem(CART_KEY, JSON.stringify(cartItems)).catch(() => {});
  }, [cartItems, loaded]);

  function addToCart(product) {
    const amount = Number(product.quantity) || 1;

    setCartItems((currentItems) => {
      const existing = currentItems.find(
        (item) => String(item.id) === String(product.id)
      );

      if (existing) {
        return currentItems.map((item) =>
          String(item.id) === String(product.id)
            ? { ...item, quantity: item.quantity + amount }
            : item
        );
      }

      return [...currentItems, { ...product, quantity: amount }];
    });
  }

  function increaseQuantity(id) {
    setCartItems((items) =>
      items.map((item) =>
        String(item.id) === String(id)
          ? { ...item, quantity: item.quantity + 1 }
          : item
      )
    );
  }

  function decreaseQuantity(id) {
    setCartItems((items) =>
      items
        .map((item) =>
          String(item.id) === String(id)
            ? { ...item, quantity: item.quantity - 1 }
            : item
        )
        .filter((item) => item.quantity > 0)
    );
  }

  function removeFromCart(id) {
    setCartItems((items) =>
      items.filter((item) => String(item.id) !== String(id))
    );
  }

  function clearCart() {
    setCartItems([]);
  }

  return (
    <CartContext.Provider
      value={{
        cartItems,
        addToCart,
        increaseQuantity,
        decreaseQuantity,
        removeFromCart,
        clearCart,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  return useContext(CartContext);
}