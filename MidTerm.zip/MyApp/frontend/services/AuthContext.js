import React, { createContext, useContext, useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const USERS_KEY = 'auth:users';
const SESSION_KEY = 'auth:session';

const AuthContext = createContext();

async function readJSON(key, fallback) {
  try {
    const raw = await AsyncStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (error) {
    return fallback;
  }
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);

  // Restore the saved login session when the app starts
  useEffect(() => {
    async function restoreSession() {
      const session = await readJSON(SESSION_KEY, null);
      setUser(session);
      setAuthLoading(false);
    }
    restoreSession();
  }, []);

  async function signup({ name, email, password }) {
    const cleanEmail = email.trim().toLowerCase();
    const users = await readJSON(USERS_KEY, []);

    if (users.some((item) => item.email === cleanEmail)) {
      throw new Error('An account with this email already exists. Please login.');
    }

    // Demo only: a real app must never store plain-text passwords.
    const newUser = { name: name.trim(), email: cleanEmail, password };
    await AsyncStorage.setItem(USERS_KEY, JSON.stringify([...users, newUser]));

    const session = { name: newUser.name, email: newUser.email };
    await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(session));
    setUser(session);
    return session;
  }

  async function login({ email, password }) {
    const cleanEmail = email.trim().toLowerCase();
    const users = await readJSON(USERS_KEY, []);
    const found = users.find((item) => item.email === cleanEmail);

    if (!found) {
      throw new Error('No account found with this email. Please sign up first.');
    }
    if (found.password !== password) {
      throw new Error('Incorrect password. Please try again.');
    }

    const session = { name: found.name, email: found.email };
    await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(session));
    setUser(session);
    return session;
  }

  async function logout() {
    await AsyncStorage.removeItem(SESSION_KEY);
    setUser(null);
  }

  return (
    <AuthContext.Provider value={{ user, authLoading, signup, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}