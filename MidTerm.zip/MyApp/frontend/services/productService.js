

const API_URL = 'https://fakestoreapi.com/products';

// FakeStoreAPI prices are in US dollars. This demo rate turns them into Rs.

const USD_TO_PKR = 100;

// fetchProducts()                 -> every product from the API
// fetchProducts("men's clothing") -> only that API category
export async function fetchProducts(category) {
  const response = await fetch(API_URL);

  if (!response.ok) {
    throw new Error('Failed to fetch products');
  }

  const data = await response.json();

  const list = category
    ? data.filter((product) => product.category === category)
    : data;

  return list.map((product) => ({
    ...product,
    name: product.title,
    image: product.image,
    price: Math.round(Number(product.price) * USD_TO_PKR),
  }));
}