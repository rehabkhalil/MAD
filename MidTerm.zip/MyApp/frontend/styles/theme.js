const theme = {
  colors: {
    primary: '#8C2946',
    secondary: '#E7A6B2',
    background: '#FFF5EB',
    white: '#FFFFFF',
    text: '#29242A',
    gold: '#C9A56A',
    muted: '#777777',
    border: '#EADDE0',
    success: '#38764B',
    danger: '#C0392B',

    // Reusable extra colors
    lightPink: '#F1DFE3',
    softPink: '#F8E8E9',
    lightGold: '#F5DCA8',
    placeholder: '#999999',
    iconMuted: '#888888',
    lightBorder: '#F1E8E8',
    inactiveDot: '#B96D81',
    switchTrack: '#D8C8CC',

     // Splash screen
    patternLine: 'rgba(255, 255, 255, 0.07)',
    halo: 'rgba(255, 255, 255, 0.14)',
    dotFaded: 'rgba(245, 220, 168, 0.4)',

    // Moving banner backgrounds
    bannerPlum: '#642D4D',
    bannerRose: '#A23E68',
    bannerBronze: '#8A5B22',
  },

   // Custom fonts (loaded with expo-font / @expo-google-fonts)
  fonts: {
    serifBold: 'PlayfairDisplay_700Bold',
    serifItalic: 'PlayfairDisplay_400Regular_Italic',
    sans: 'Poppins_400Regular',
    sansMedium: 'Poppins_500Medium',
  },

  fontSize: {
    tiny: 10,
    caption: 11,
    small: 12,
    compact: 13,
    regular: 14,
    medium: 15,
    body: 16,
    large: 17,
    subheading: 20,
    heading: 22,
    xlarge: 26,
    title: 28,
    display: 32,
  },

  fontWeight: {
    medium: '600',
    semibold: '700',
    bold: 'bold',
    heavy: '800',
    black: '900',
  },

  lineHeight: {
    small: 18,
    regular: 20,
    body: 22,
    heading: 32,
  },

  letterSpacing: {
    small: 1,
    medium: 2,
  },

  spacing: {
    tiny: 4,
    small: 8,
    medium: 16,
    large: 24,
    screen: 22,
    section: 28,
    xl: 36,
  },

  radius: {
    small: 8,
    medium: 14,
    large: 22,
    round: 999,
  },

  borderWidth: {
    thin: 1,
    medium: 2,
    thick: 3,
  },

  // Emoji / icon text sizes
  iconSize: {
    small: 36,
    medium: 48,
    large: 58,
    hero: 100,
  },

  opacity: {
    pressed: 0.85,
    soft: 0.9,
  },
};

export default theme;