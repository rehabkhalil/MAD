import { StyleSheet } from 'react-native';
import theme from './theme';

const globalStyles = StyleSheet.create({
  // Screen and layout
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  screenContent: {
    paddingHorizontal: theme.spacing.screen,
    paddingTop: theme.spacing.large,
    paddingBottom: theme.spacing.xl,
  },
  centered: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  rowBetween: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },

  // Maroon page header (Cart, Checkout, Categories)
  pageHeader: {
    backgroundColor: theme.colors.primary,
    padding: theme.spacing.large,
    paddingTop: theme.spacing.section,
    borderBottomLeftRadius: theme.radius.large,
    borderBottomRightRadius: theme.radius.large,
  },
  pageBrand: {
    color: theme.colors.lightGold,
    fontSize: theme.fontSize.caption,
    fontWeight: theme.fontWeight.bold,
    letterSpacing: theme.letterSpacing.medium,
  },
  pageTitle: {
    color: theme.colors.white,
    fontSize: theme.fontSize.xlarge,
    fontWeight: theme.fontWeight.black,
    marginTop: theme.spacing.small,
  },
  pageSubtitle: {
    color: theme.colors.softPink,
    fontSize: theme.fontSize.regular,
    marginTop: theme.spacing.small,
  },

  // Typography
  heading: {
    fontSize: theme.fontSize.heading,
    fontWeight: theme.fontWeight.bold,
    color: theme.colors.primary,
  },
  title: {
    fontSize: theme.fontSize.title,
    fontWeight: theme.fontWeight.black,
    color: theme.colors.primary,
  },
  text: {
    fontSize: theme.fontSize.body,
    color: theme.colors.text,
  },
  bodyText: {
    fontSize: theme.fontSize.regular,
    color: theme.colors.text,
    lineHeight: theme.lineHeight.body,
  },
  mutedText: {
    fontSize: theme.fontSize.small,
    color: theme.colors.muted,
  },

  // Buttons
  button: {
    backgroundColor: theme.colors.primary,
    padding: theme.spacing.medium,
    borderRadius: theme.radius.medium,
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonText: {
    color: theme.colors.white,
    fontSize: theme.fontSize.body,
    fontWeight: theme.fontWeight.bold,
    textAlign: 'center',
  },
  secondaryButton: {
    borderWidth: theme.borderWidth.thin,
    borderColor: theme.colors.primary,
    borderRadius: theme.radius.medium,
    padding: theme.spacing.medium,
    alignItems: 'center',
    justifyContent: 'center',
  },
  secondaryButtonText: {
    color: theme.colors.primary,
    fontSize: theme.fontSize.regular,
    fontWeight: theme.fontWeight.bold,
    textAlign: 'center',
  },

  // Cards
  card: {
    backgroundColor: theme.colors.white,
    borderRadius: theme.radius.medium,
    padding: theme.spacing.medium,
    borderWidth: theme.borderWidth.thin,
    borderColor: theme.colors.border,
  },

  // Form fields
  input: {
    backgroundColor: theme.colors.white,
    borderWidth: theme.borderWidth.thin,
    borderColor: theme.colors.border,
    borderRadius: theme.radius.medium,
    paddingHorizontal: theme.spacing.medium,
    paddingVertical: theme.spacing.medium,
    fontSize: theme.fontSize.regular,
    color: theme.colors.text,
  },

  // Dividers and spacing
  divider: {
    height: 1,
    backgroundColor: theme.colors.border,
  },
  sectionSpacing: {
    marginTop: theme.spacing.section,
  },
  bottomSpace: {
    height: 25,
  },
});

export default globalStyles;