import React, { useState } from 'react';
import { View, Text, ScrollView, Image, TouchableOpacity, StyleSheet, Alert } from 'react-native';

import theme from '../styles/theme';
import globalStyles from '../styles/globalStyles';
import { useAuth } from '../services/AuthContext';
import { useCart } from '../services/CartContext';

const sizeGuide = {
  Small: { chest: '22.5', shoulder: '17.25', length: '41' },
  Medium: { chest: '23.5', shoulder: '18.25', length: '42' },
  Large: { chest: '24.5', shoulder: '19.25', length: '43' },
};

const defaultCare = 'Follow the care label provided with the garment.';
const defaultFabric = 'Fabric details to be confirmed';

const fabricDetails = {
  'stitched-1': { fabric: defaultFabric, fit: 'Regular fit', care: defaultCare, colour: 'Black' },
  'stitched-2': { fabric: defaultFabric, fit: 'Regular fit', care: defaultCare, colour: 'Charcoal Grey' },
  'stitched-3': {
    fabric: 'Boski-style embroidered design; exact composition to be confirmed',
    fit: 'Regular fit',
    care: 'Handle embroidery carefully and follow the garment care label.',
    colour: 'Cream',
  },
  'stitched-4': { fabric: defaultFabric, fit: 'Regular fit', care: defaultCare, colour: 'Emerald Green' },
  'stitched-5': { fabric: defaultFabric, fit: 'Regular fit', care: defaultCare, colour: 'Navy Blue' },
  'stitched-6': { fabric: defaultFabric, fit: 'Regular fit', care: defaultCare, colour: 'Fern Green' },
};

export default function ProductDetailsScreen({ route, navigation }) {
  const { product, category, audience, subcategory } = route.params;

  const { user } = useAuth();
  const { addToCart } = useCart();

  const [selectedSize, setSelectedSize] = useState(product.selectedSize || 'Medium');
  const [quantity, setQuantity] = useState(1);

  const idText = String(product.id);
  const isClothes = category === 'Clothes';
  const isStitched = idText.startsWith('stitched-') || idText.startsWith('women-stitched-');
  const isUnstitched = idText.startsWith('unstitched-') || idText.startsWith('women-unstitched-');

  const saved = fabricDetails[product.id] || {};
  const details = {
    fabric: product.fabric || saved.fabric || 'Fabric composition to be confirmed with the seller.',
    fit: isUnstitched ? 'Unstitched fabric — stitching required' : saved.fit || 'Regular fit',
    care: product.care || saved.care || 'Follow the care instructions provided by the seller.',
    colour: product.colour || saved.colour || 'As shown in the product image',
  };

  const measurement = sizeGuide[selectedSize];
  const lineTotal = (Number(product.price || 0) * quantity).toLocaleString('en-PK');

  const handleAddToCart = () => {
    const cartProduct = {
      ...product,
      id: isStitched ? `${product.id}-${selectedSize}` : product.id,
      originalProductId: product.id,
      selectedSize: isStitched ? selectedSize : undefined,
      quantity,
    };

    // Not logged in -> open the Authentication screen first
    if (!user) {
      navigation.navigate('Auth', { product: cartProduct });
      return;
    }

    // Logged in -> add to cart directly
    addToCart(cartProduct);

    Alert.alert('Added to Cart', `${product.name || product.title} has been added to your cart.`, [
      { text: 'Continue Shopping' },
      { text: 'View Cart', onPress: () => navigation.navigate('Home', { screen: 'Cart' }) },
    ]);
  };

  return (
    <ScrollView
      style={globalStyles.container}
      contentContainerStyle={styles.content}
      showsVerticalScrollIndicator={false}
    >
      <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
        <Text style={styles.backText}>‹  Back to Collection</Text>
      </TouchableOpacity>

      {/* Product image */}
      <View style={[globalStyles.card, globalStyles.centered, styles.imageContainer]}>
        {product.image ? (
          <Image
            source={typeof product.image === 'string' ? { uri: product.image } : product.image}
            style={styles.productImage}
            resizeMode="contain"
          />
        ) : (
          <Text style={styles.emoji}>{product.emoji || '👔'}</Text>
        )}

        <View style={styles.imageBadge}>
          <Text style={styles.imageBadgeText}>RANG-E-RIWAAJ</Text>
        </View>
      </View>

      <View style={styles.detailsContainer}>
        <Text style={styles.categoryLabel}>
          {category === 'Makeup' ? 'Makeup' : audience || 'Collection'}
          {subcategory ? ` • ${subcategory}` : ''}
        </Text>

        <Text style={styles.productName}>{product.name || product.title}</Text>

        <Text style={styles.price}>
          Rs. {Number(product.price || 0).toLocaleString('en-PK')}
        </Text>

        <Text style={styles.availability}>✓ Available for ordering</Text>

        <View style={[globalStyles.divider, styles.separator]} />

        <Text style={styles.sectionTitle}>Product Description</Text>
        <Text style={[globalStyles.bodyText, styles.description]}>
          {product.description ||
            'Explore this item from our collection. Check the product image and available options before ordering.'}
        </Text>

        <Text style={styles.sectionTitle}>Product Information</Text>
        <View style={[globalStyles.card, styles.tableCard]}>
          {isClothes && (
            <>
              <InfoRow label="Colour" value={details.colour} />
              <InfoRow label="Fit" value={details.fit} />
              <InfoRow label="Fabric" value={details.fabric} />
            </>
          )}
          {isUnstitched && (
            <InfoRow label="Fabric Length" value={product.length || 'Confirm with seller'} />
          )}
          {product.rating ? (
            <InfoRow
              label="Rating"
              value={`${product.rating.rate} / 5 (${product.rating.count} reviews)`}
            />
          ) : null}
          <InfoRow
            label="Category"
            value={`${category || 'Fashion'}${subcategory ? ` - ${subcategory}` : ''}`}
          />
        </View>

        {isStitched && (
          <>
            <Text style={styles.sectionTitle}>Select Your Size</Text>
            <Text style={[globalStyles.mutedText, styles.helperText]}>
              Choose the size that suits you best.
            </Text>

            <View style={styles.sizeRow}>
              {['Small', 'Medium', 'Large'].map((size) => {
                const active = selectedSize === size;
                return (
                  <TouchableOpacity
                    key={size}
                    style={[styles.sizeButton, active && styles.selectedSizeButton]}
                    onPress={() => setSelectedSize(size)}
                  >
                    <Text style={[styles.sizeButtonText, active && styles.selectedSizeText]}>
                      {size[0]}
                    </Text>
                    <Text style={[styles.sizeFullText, active && styles.selectedSizeText]}>
                      {size}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>

            <Text style={styles.sectionTitle}>Size Guide (inches)</Text>

            <View style={[globalStyles.card, styles.tableCard, styles.measureCard]}>
              <View style={[globalStyles.rowBetween, styles.measureHeader]}>
                <Text style={styles.measureHeaderText}>Measurement</Text>
                <Text style={styles.measureHeaderText}>Size</Text>
              </View>

              <MeasureRow label="Chest (flat)" value={`${measurement.chest}"`} />
              <MeasureRow label="Shoulder" value={`${measurement.shoulder}"`} />
              <MeasureRow label="Garment length" value={`${measurement.length}"`} />

              <View style={styles.selectedSizeInfo}>
                <Text style={styles.selectedSizeInfoText}>Selected size: {selectedSize}</Text>
              </View>
            </View>

            <Text style={[globalStyles.mutedText, styles.measureNote]}>
              Note: These are sample measurements for demonstration, not verified measurements
              for this specific product. Chest is measured flat across the garment. Please
              check the seller's actual size chart before purchasing.
            </Text>
          </>
        )}

        <Text style={styles.sectionTitle}>Quantity</Text>
        <View style={[globalStyles.card, globalStyles.row, styles.quantityRow]}>
          <TouchableOpacity
            style={styles.quantityButton}
            disabled={quantity <= 1}
            onPress={() => setQuantity((current) => current - 1)}
          >
            <Text style={styles.quantityButtonText}>−</Text>
          </TouchableOpacity>

          <Text style={styles.quantityValue}>{quantity}</Text>

          <TouchableOpacity
            style={styles.quantityButton}
            onPress={() => setQuantity((current) => current + 1)}
          >
            <Text style={styles.quantityButtonText}>+</Text>
          </TouchableOpacity>
        </View>

        {isClothes && (
          <>
            <Text style={styles.sectionTitle}>Care Instructions</Text>
            <View style={[globalStyles.card, styles.careCard]}>
              <Text style={styles.careIcon}>✦</Text>
              <Text style={[globalStyles.mutedText, styles.careText]}>{details.care}</Text>
            </View>
          </>
        )}

        <View style={[globalStyles.rowBetween, styles.totalRow]}>
          <Text style={styles.totalLabel}>Subtotal</Text>
          <Text style={styles.totalPrice}>Rs. {lineTotal}</Text>
        </View>

        <TouchableOpacity style={[globalStyles.button, styles.addButton]} onPress={handleAddToCart}>
          <Text style={styles.addButtonText}>Add to Cart  •  Rs. {lineTotal}</Text>
        </TouchableOpacity>

        {!user && (
          <Text style={[globalStyles.mutedText, styles.loginHint]}>
            You will be asked to login before adding items to your cart.
          </Text>
        )}

        <Text style={[globalStyles.mutedText, styles.footerText]}>
          Rang-e-Riwaaj • Traditional style, timeless elegance
        </Text>
      </View>
    </ScrollView>
  );
}

function InfoRow({ label, value }) {
  return (
    <View style={styles.infoRow}>
      <Text style={styles.infoLabel}>{label}</Text>
      <Text style={styles.infoValue}>{value}</Text>
    </View>
  );
}

function MeasureRow({ label, value }) {
  return (
    <View style={[globalStyles.rowBetween, styles.measureRow]}>
      <Text style={styles.measureLabel}>{label}</Text>
      <Text style={styles.measureValue}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  content: { paddingBottom: theme.spacing.xl },
  backButton: {
    paddingHorizontal: theme.spacing.screen,
    paddingVertical: theme.spacing.medium,
  },
  backText: {
    color: theme.colors.primary,
    fontSize: theme.fontSize.medium,
    fontWeight: theme.fontWeight.semibold,
  },
  imageContainer: {
    height: 330,
    marginHorizontal: theme.spacing.medium,
    borderRadius: theme.radius.large,
    padding: 0,
    overflow: 'hidden',
  },
  productImage: {
    width: '100%',
    height: '100%',
  },
  emoji: { fontSize: theme.iconSize.hero },
  imageBadge: {
    position: 'absolute',
    bottom: 12,
    right: 12,
    backgroundColor: theme.colors.primary,
    paddingHorizontal: theme.spacing.small,
    paddingVertical: theme.spacing.small,
    borderRadius: theme.radius.small,
  },
  imageBadgeText: {
    color: theme.colors.white,
    fontSize: theme.fontSize.tiny,
    fontWeight: theme.fontWeight.bold,
    letterSpacing: theme.letterSpacing.small,
  },
  detailsContainer: {
    paddingHorizontal: theme.spacing.screen,
    paddingTop: theme.spacing.screen,
  },
  categoryLabel: {
    color: theme.colors.primary,
    fontSize: theme.fontSize.small,
    fontWeight: theme.fontWeight.bold,
    textTransform: 'uppercase',
    letterSpacing: theme.letterSpacing.small,
  },
  productName: {
    color: theme.colors.text,
    fontSize: theme.fontSize.xlarge,
    fontWeight: theme.fontWeight.black,
    marginTop: theme.spacing.small,
    lineHeight: theme.lineHeight.heading,
  },
  price: {
    color: theme.colors.primary,
    fontSize: theme.fontSize.xlarge,
    fontWeight: theme.fontWeight.black,
    marginTop: theme.spacing.small,
  },
  availability: {
    color: theme.colors.success,
    fontSize: theme.fontSize.small,
    fontWeight: theme.fontWeight.medium,
    marginTop: theme.spacing.small,
  },
  separator: { marginVertical: theme.spacing.screen },
  sectionTitle: {
    color: theme.colors.text,
    fontSize: theme.fontSize.large,
    fontWeight: theme.fontWeight.heavy,
    marginTop: theme.spacing.screen,
    marginBottom: theme.spacing.small,
  },
  description: {
    color: theme.colors.muted,
    lineHeight: theme.lineHeight.body,
  },
  tableCard: {
    padding: 0,
    paddingHorizontal: theme.spacing.medium,
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    paddingVertical: theme.spacing.medium,
    borderBottomWidth: theme.borderWidth.thin,
    borderBottomColor: theme.colors.lightBorder,
    gap: theme.spacing.medium,
  },
  infoLabel: {
    color: theme.colors.muted,
    fontSize: theme.fontSize.compact,
    flex: 1,
  },
  infoValue: {
    color: theme.colors.text,
    fontSize: theme.fontSize.compact,
    fontWeight: theme.fontWeight.medium,
    flex: 1.3,
    textAlign: 'right',
  },
  helperText: { marginBottom: theme.spacing.medium },
  sizeRow: {
    flexDirection: 'row',
    gap: theme.spacing.medium,
  },
  sizeButton: {
    flex: 1,
    minHeight: 68,
    borderRadius: theme.radius.medium,
    borderWidth: theme.borderWidth.thin,
    borderColor: theme.colors.border,
    backgroundColor: theme.colors.white,
    alignItems: 'center',
    justifyContent: 'center',
  },
  selectedSizeButton: {
    backgroundColor: theme.colors.primary,
    borderColor: theme.colors.primary,
  },
  sizeButtonText: {
    color: theme.colors.text,
    fontSize: theme.fontSize.large,
    fontWeight: theme.fontWeight.black,
  },
  sizeFullText: {
    color: theme.colors.muted,
    fontSize: theme.fontSize.tiny,
    marginTop: theme.spacing.tiny,
  },
  selectedSizeText: { color: theme.colors.white },
  measureCard: {
    paddingHorizontal: 0,
    overflow: 'hidden',
  },
  measureHeader: {
    backgroundColor: theme.colors.softPink,
    paddingHorizontal: theme.spacing.medium,
    paddingVertical: theme.spacing.medium,
  },
  measureHeaderText: {
    color: theme.colors.primary,
    fontSize: theme.fontSize.small,
    fontWeight: theme.fontWeight.heavy,
  },
  measureRow: {
    paddingHorizontal: theme.spacing.medium,
    paddingVertical: theme.spacing.medium,
    borderBottomWidth: theme.borderWidth.thin,
    borderBottomColor: theme.colors.lightBorder,
  },
  measureLabel: {
    color: theme.colors.text,
    fontSize: theme.fontSize.compact,
  },
  measureValue: {
    color: theme.colors.primary,
    fontSize: theme.fontSize.compact,
    fontWeight: theme.fontWeight.heavy,
  },
  selectedSizeInfo: {
    padding: theme.spacing.medium,
    backgroundColor: theme.colors.background,
  },
  selectedSizeInfoText: {
    color: theme.colors.primary,
    fontSize: theme.fontSize.small,
    fontWeight: theme.fontWeight.bold,
  },
  measureNote: {
    fontSize: theme.fontSize.caption,
    lineHeight: theme.lineHeight.small,
    marginTop: theme.spacing.small,
  },
  quantityRow: {
    alignSelf: 'flex-start',
    gap: theme.spacing.medium,
    borderRadius: theme.radius.medium,
    padding: theme.spacing.small,
  },
  quantityButton: {
    width: 38,
    height: 38,
    borderRadius: theme.radius.small,
    backgroundColor: theme.colors.softPink,
    alignItems: 'center',
    justifyContent: 'center',
  },
  quantityButtonText: {
    color: theme.colors.primary,
    fontSize: theme.fontSize.xlarge,
    fontWeight: theme.fontWeight.bold,
  },
  quantityValue: {
    color: theme.colors.text,
    fontSize: theme.fontSize.large,
    fontWeight: theme.fontWeight.bold,
    minWidth: 18,
    textAlign: 'center',
  },
  careCard: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: theme.spacing.small,
    borderRadius: theme.radius.medium,
    padding: theme.spacing.medium,
  },
  careIcon: {
    color: theme.colors.gold,
    fontSize: theme.fontSize.subheading,
    fontWeight: theme.fontWeight.bold,
  },
  careText: {
    flex: 1,
    lineHeight: theme.lineHeight.small,
  },
  totalRow: {
    marginTop: theme.spacing.large,
    paddingVertical: theme.spacing.medium,
    borderTopWidth: theme.borderWidth.thin,
    borderTopColor: theme.colors.border,
  },
  totalLabel: {
    color: theme.colors.text,
    fontSize: theme.fontSize.medium,
    fontWeight: theme.fontWeight.semibold,
  },
  totalPrice: {
    color: theme.colors.primary,
    fontSize: theme.fontSize.subheading,
    fontWeight: theme.fontWeight.black,
  },
  addButton: {
    paddingVertical: theme.spacing.medium,
    paddingHorizontal: theme.spacing.medium,
    marginTop: theme.spacing.small,
  },
  addButtonText: {
    color: theme.colors.white,
    fontSize: theme.fontSize.medium,
    fontWeight: theme.fontWeight.heavy,
    textAlign: 'center',
  },
  loginHint: {
    textAlign: 'center',
    marginTop: theme.spacing.small,
  },
  footerText: {
    textAlign: 'center',
    fontSize: theme.fontSize.caption,
    marginTop: theme.spacing.screen,
  },
});