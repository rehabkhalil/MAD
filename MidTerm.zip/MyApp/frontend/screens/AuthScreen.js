import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Alert,
  Switch,
  ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import theme from '../styles/theme';
import globalStyles from '../styles/globalStyles';
import { useCart } from '../services/CartContext';
import { useAuth } from '../services/AuthContext';

export default function AuthScreen({ route, navigation }) {
  const [isSignup, setIsSignup] = useState(route.params?.mode === 'signup');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const { addToCart } = useCart();
  const { login, signup } = useAuth();

  // Product the user wanted to add before being asked to login
  const product = route.params?.product;

  async function handleAuth() {
    if (!email.trim() || !password.trim()) {
      Alert.alert('Missing Information', 'Please enter your email and password.');
      return;
    }
    if (!email.includes('@')) {
      Alert.alert('Invalid Email', 'Please enter a valid email address.');
      return;
    }
    if (password.length < 6) {
      Alert.alert('Password Too Short', 'Password must be at least 6 characters.');
      return;
    }
    if (isSignup && !name.trim()) {
      Alert.alert('Name Required', 'Please enter your name.');
      return;
    }

    try {
      setSubmitting(true);

      if (isSignup) {
        await signup({ name, email, password });
      } else {
        await login({ email, password });
      }

      // After login, add the product the user selected earlier
      if (product) {
        addToCart(product);
      }

      Alert.alert(
        isSignup ? 'Account Created!' : 'Login Successful',
        product ? 'Your product has been added to the cart.' : 'Welcome to Rang-e-Riwaaj.',
        [
          {
            text: 'OK',
            onPress: () => {
              if (product) {
                navigation.navigate('Home', { screen: 'Cart' });
              } else if (route.params?.returnToProfile) {
                navigation.navigate('Home', { screen: 'Profile' });
              } else {
                navigation.navigate('Home', { screen: 'Shop' });
              }
            },
          },
        ]
      );
    } catch (error) {
      Alert.alert(isSignup ? 'Signup Failed' : 'Login Failed', error.message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <ScrollView
      style={globalStyles.container}
      contentContainerStyle={styles.content}
      keyboardShouldPersistTaps="handled"
    >
      <View style={styles.logoCircle}>
        <Ionicons name="bag-handle" size={34} color={theme.colors.white} />
      </View>

      <Text style={styles.brand}>Rang-e-Riwaaj</Text>
      <Text style={styles.tagline}>Your style, your tradition</Text>

      <View style={[globalStyles.card, styles.formCard]}>
        <Text style={styles.heading}>{isSignup ? 'Create Account' : 'Welcome Back'}</Text>

        <Text style={[globalStyles.mutedText, styles.subtitle]}>
          {isSignup
            ? 'Join us and discover your style.'
            : product
              ? 'Please login to add this product to your cart.'
              : 'Login to continue shopping.'}
        </Text>

        {isSignup && (
          <View style={[globalStyles.input, globalStyles.row, styles.inputBox]}>
            <Ionicons name="person-outline" size={20} color={theme.colors.primary} />
            <TextInput
              style={styles.inputText}
              placeholder="Full Name"
              placeholderTextColor={theme.colors.placeholder}
              value={name}
              onChangeText={setName}
              autoCapitalize="words"
            />
          </View>
        )}

        <View style={[globalStyles.input, globalStyles.row, styles.inputBox]}>
          <Ionicons name="mail-outline" size={20} color={theme.colors.primary} />
          <TextInput
            style={styles.inputText}
            placeholder="Email Address"
            placeholderTextColor={theme.colors.placeholder}
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
          />
        </View>

        <View style={[globalStyles.input, globalStyles.row, styles.inputBox]}>
          <Ionicons name="lock-closed-outline" size={20} color={theme.colors.primary} />
          <TextInput
            style={styles.inputText}
            placeholder="Password (minimum 6 characters)"
            placeholderTextColor={theme.colors.placeholder}
            value={password}
            onChangeText={setPassword}
            secureTextEntry={!showPassword}
            autoCapitalize="none"
          />
        </View>

        <View style={[globalStyles.rowBetween, styles.switchRow]}>
          <Text style={styles.switchLabel}>Show password</Text>
          <Switch
            value={showPassword}
            onValueChange={setShowPassword}
            trackColor={{ false: theme.colors.switchTrack, true: theme.colors.secondary }}
            thumbColor={showPassword ? theme.colors.primary : theme.colors.white}
          />
        </View>

        <TouchableOpacity
          style={[globalStyles.button, styles.mainButton]}
          activeOpacity={theme.opacity.pressed}
          onPress={handleAuth}
          disabled={submitting}
        >
          {submitting ? (
            <ActivityIndicator color={theme.colors.white} />
          ) : (
            <Text style={styles.mainButtonText}>{isSignup ? 'CREATE ACCOUNT' : 'LOGIN'}</Text>
          )}
        </TouchableOpacity>

        <TouchableOpacity style={styles.toggleButton} onPress={() => setIsSignup(!isSignup)}>
          <Text style={styles.toggleText}>
            {isSignup ? 'Already have an account? Login' : "Don't have an account? Sign Up"}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <Text style={globalStyles.mutedText}>← Back to shopping</Text>
        </TouchableOpacity>
      </View>

      <Text style={[globalStyles.mutedText, styles.demoNote]}>
        Demo project • Data is saved only on this device
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  content: {
    paddingHorizontal: theme.spacing.screen,
    paddingTop: theme.spacing.xl,
    paddingBottom: theme.spacing.section,
    alignItems: 'center',
  },
  logoCircle: {
    width: 75,
    height: 75,
    borderRadius: theme.radius.round,
    backgroundColor: theme.colors.primary,
    borderWidth: theme.borderWidth.medium,
    borderColor: theme.colors.gold,
    alignItems: 'center',
    justifyContent: 'center',
  },
  brand: {
    color: theme.colors.primary,
    fontSize: theme.fontSize.xlarge,
    fontWeight: theme.fontWeight.black,
    marginTop: theme.spacing.medium,
  },
  tagline: {
    color: theme.colors.muted,
    fontSize: theme.fontSize.compact,
    fontStyle: 'italic',
    marginTop: theme.spacing.tiny,
    marginBottom: theme.spacing.large,
  },
  formCard: {
    width: '100%',
    borderRadius: theme.radius.large,
    padding: theme.spacing.screen,
  },
  heading: {
    color: theme.colors.primary,
    fontSize: theme.fontSize.xlarge,
    fontWeight: theme.fontWeight.black,
  },
  subtitle: {
    fontSize: theme.fontSize.compact,
    marginTop: theme.spacing.small,
    marginBottom: theme.spacing.screen,
  },
  inputBox: {
    backgroundColor: theme.colors.background,
    borderRadius: theme.radius.medium,
    paddingVertical: 0,
    marginBottom: theme.spacing.medium,
  },
  inputText: {
    flex: 1,
    height: 48,
    marginLeft: theme.spacing.small,
    fontSize: theme.fontSize.regular,
    color: theme.colors.text,
  },
  switchRow: { marginBottom: theme.spacing.medium },
  switchLabel: {
    color: theme.colors.text,
    fontSize: theme.fontSize.compact,
  },
  mainButton: {
    paddingVertical: theme.spacing.medium,
    borderRadius: theme.radius.medium,
  },
  mainButtonText: {
    color: theme.colors.white,
    fontSize: theme.fontSize.regular,
    fontWeight: theme.fontWeight.bold,
    letterSpacing: theme.letterSpacing.small,
  },
  toggleButton: {
    alignItems: 'center',
    paddingTop: theme.spacing.screen,
  },
  toggleText: {
    color: theme.colors.primary,
    fontSize: theme.fontSize.compact,
    fontWeight: theme.fontWeight.bold,
    textAlign: 'center',
  },
  backButton: {
    alignItems: 'center',
    paddingTop: theme.spacing.medium,
  },
  demoNote: {
    textAlign: 'center',
    marginTop: theme.spacing.medium,
  },
});