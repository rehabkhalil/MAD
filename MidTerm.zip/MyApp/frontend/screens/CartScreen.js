import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Image } from 'react-native';

import theme from '../styles/theme';
import globalStyles from '../styles/globalStyles';
import { useCart } from '../services/CartContext';
import { Ionicons } from '@expo/vector-icons';

export default function CartScreen({ navigation }) {
  const { cartItems, increaseQuantity, decreaseQuantity, removeFromCart } = useCart();

  const subtotal = cartItems.reduce(
    (sum, item) => sum + Number(item.price) * item.quantity,
    0
  );
    const discount = subtotal > 1200 ? Math.round(subtotal * 0.2) : 0;
  const total = subtotal - discount;

   const money = (value) =>
    value.toLocaleString('en-PK', { maximumFractionDigits: 0 });

  return (
    <ScrollView style={globalStyles.container}>
      <View style={globalStyles.pageHeader}>
        <Text style={globalStyles.pageBrand}>RANG-E-RIWAAJ</Text>
       <View style={styles.titleRow}>
          <Text style={globalStyles.pageTitle}>My Shopping Bag</Text>
          <View style={styles.iconCircle}>
            <Ionicons name="bag-handle-outline" size={22} color={theme.colors.primary} />
          </View>
        </View>
        
        <Text style={globalStyles.pageSubtitle}>
          {cartItems.length} different item(s) in your bag
        </Text>
      </View>

      {cartItems.length === 0 ? (
        <View style={[globalStyles.card, globalStyles.centered, styles.emptyBox]}>
          <View style={styles.emptyIconCircle}>
            <Ionicons name="bag-handle-outline" size={44} color={theme.colors.primary} />
          </View>
          <Text style={styles.emptyTitle}>Your bag is waiting!</Text>
          <Text style={[globalStyles.mutedText, styles.emptyText]}>
            Explore our collection and add your favourite items.
          </Text>

          <TouchableOpacity
            style={[globalStyles.button, styles.button]}
            onPress={() => navigation.navigate('Shop')}
          >
            <Text style={styles.buttonText}>CONTINUE SHOPPING</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <>
          {cartItems.map((item) => (
            <View key={String(item.id)} style={[globalStyles.card, styles.itemCard]}>
              <View style={[globalStyles.centered, styles.itemImage]}>
                {item.image ? (
                  <Image
                    source={typeof item.image === 'string' ? { uri: item.image } : item.image}
                    style={styles.itemImageFill}
                    resizeMode="contain"
                  />
                ) : (
                  <Text style={styles.itemEmoji}>{item.emoji || '🛍️'}</Text>
                )}
              </View>

              <View style={styles.itemInfo}>
                <Text style={styles.itemName}>{item.name || item.title}</Text>
                {item.selectedSize ? (
                  <Text style={globalStyles.mutedText}>Size: {item.selectedSize}</Text>
                ) : null}
                <Text style={styles.itemPrice}>
                  Rs. {Number(item.price).toLocaleString('en-PK')}
                </Text>

                <View style={[globalStyles.row, styles.quantityRow]}>
                  <TouchableOpacity
                    style={styles.quantityButton}
                    onPress={() => decreaseQuantity(item.id)}
                  >
                    <Text style={styles.quantitySymbol}>−</Text>
                  </TouchableOpacity>

                  <Text style={styles.quantity}>{item.quantity}</Text>

                  <TouchableOpacity
                    style={styles.quantityButton}
                    onPress={() => increaseQuantity(item.id)}
                  >
                    <Text style={styles.quantitySymbol}>+</Text>
                  </TouchableOpacity>
                </View>

                <TouchableOpacity onPress={() => removeFromCart(item.id)}>
                  <Text style={styles.removeText}>Remove item</Text>
                </TouchableOpacity>
              </View>
            </View>
          ))}

          <View style={[globalStyles.card, styles.summary]}>
            <Text style={styles.summaryTitle}>Order Summary</Text>

            <View style={[globalStyles.rowBetween, styles.summaryRow]}>
              <Text style={styles.summaryLabel}>Subtotal</Text>
              <Text style={styles.summaryValue}>Rs. {money(subtotal)}</Text>
            </View>

            <View style={[globalStyles.rowBetween, styles.summaryRow]}>
              <Text style={styles.summaryLabel}>Discount</Text>
              <Text style={styles.discountValue}>− Rs. {money(discount)}</Text>
            </View>

            <Text style={styles.offerNote}>
              {subtotal > 1200
                ? '🎉 You received 20% OFF!'
                : 'Spend more than Rs. 1,200 to get 20% OFF.'}
            </Text>

            <View style={[globalStyles.divider, styles.separator]} />

            <View style={[globalStyles.rowBetween, styles.summaryRow]}>
              <Text style={styles.totalLabel}>Total</Text>
              <Text style={styles.totalValue}>Rs. {money(total)}</Text>
            </View>

            <TouchableOpacity
              style={[globalStyles.button, styles.button]}
              onPress={() => navigation.navigate('Checkout')}
            >
              <Text style={styles.buttonText}>PROCEED TO CHECKOUT →</Text>
            </TouchableOpacity>
          </View>
        </>
      )}

      <View style={globalStyles.bottomSpace} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
   titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
     justifyContent: 'space-between',
  },
  iconCircle: {
    width: 36,
    height: 36,
    borderRadius: theme.radius.round,
    backgroundColor: theme.colors.background,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: theme.spacing.medium,
    marginTop: theme.spacing.small,
  },
  emptyBox: {
    margin: theme.spacing.screen,
    marginTop: theme.spacing.xl,
    padding: theme.spacing.large,
    borderRadius: theme.radius.large,
  },
  emptyEmoji: { fontSize: theme.iconSize.large },
  emptyTitle: {
    color: theme.colors.primary,
    fontSize: theme.fontSize.subheading,
    fontWeight: theme.fontWeight.bold,
    marginTop: theme.spacing.medium,
  },
  emptyText: {
    textAlign: 'center',
    fontSize: theme.fontSize.compact,
    lineHeight: theme.lineHeight.regular,
    marginTop: theme.spacing.small,
  },
  itemCard: {
    flexDirection: 'row',
    marginHorizontal: theme.spacing.medium,
    marginTop: theme.spacing.medium,
    padding: theme.spacing.medium,
    borderRadius: theme.radius.medium,
  },
  itemImage: {
    width: 90,
    height: 110,
    backgroundColor: theme.colors.softPink,
    borderRadius: theme.radius.medium,
  },
  itemImageFill: {
    width: '100%',
    height: '100%',
    borderRadius: theme.radius.medium,
  },
  itemEmoji: { fontSize: theme.iconSize.medium },
  itemInfo: {
    flex: 1,
    marginLeft: theme.spacing.medium,
    justifyContent: 'center',
  },
  itemName: {
    color: theme.colors.text,
    fontSize: theme.fontSize.medium,
    fontWeight: theme.fontWeight.bold,
  },
  itemPrice: {
    color: theme.colors.primary,
    fontSize: theme.fontSize.medium,
    fontWeight: theme.fontWeight.black,
    marginTop: theme.spacing.small,
  },
  quantityRow: {
    marginTop: theme.spacing.small,
    marginBottom: theme.spacing.small,
  },
  quantityButton: {
    width: 29,
    height: 29,
    borderRadius: theme.radius.small,
    backgroundColor: theme.colors.lightPink,
    alignItems: 'center',
    justifyContent: 'center',
  },
  quantitySymbol: {
    color: theme.colors.primary,
    fontSize: theme.fontSize.subheading,
    fontWeight: theme.fontWeight.bold,
  },
  quantity: {
    color: theme.colors.text,
    fontSize: theme.fontSize.medium,
    fontWeight: theme.fontWeight.bold,
    marginHorizontal: theme.spacing.medium,
  },
  removeText: {
    color: theme.colors.danger,
    fontSize: theme.fontSize.small,
    marginTop: theme.spacing.tiny,
  },
  summary: {
    margin: theme.spacing.medium,
    padding: theme.spacing.screen,
    borderRadius: theme.radius.large,
  },
  summaryTitle: {
    color: theme.colors.primary,
    fontSize: theme.fontSize.subheading,
    fontWeight: theme.fontWeight.black,
    marginBottom: theme.spacing.medium,
  },
  summaryRow: { marginBottom: theme.spacing.medium },
  summaryLabel: {
    color: theme.colors.muted,
    fontSize: theme.fontSize.regular,
  },
  summaryValue: {
    color: theme.colors.text,
    fontSize: theme.fontSize.regular,
    fontWeight: theme.fontWeight.medium,
  },
  discountValue: {
    color: theme.colors.success,
    fontSize: theme.fontSize.regular,
    fontWeight: theme.fontWeight.bold,
  },
  offerNote: {
    color: theme.colors.success,
    fontSize: theme.fontSize.small,
    marginBottom: theme.spacing.medium,
  },
  separator: { marginVertical: theme.spacing.tiny },
  totalLabel: {
    color: theme.colors.text,
    fontSize: theme.fontSize.large,
    fontWeight: theme.fontWeight.bold,
  },
  totalValue: {
    color: theme.colors.primary,
    fontSize: theme.fontSize.subheading,
    fontWeight: theme.fontWeight.black,
  },
  button: {
    marginTop: theme.spacing.medium,
    paddingVertical: theme.spacing.medium,
    paddingHorizontal: theme.spacing.small,
  },
  buttonText: {
    color: theme.colors.white,
    fontSize: theme.fontSize.compact,
    fontWeight: theme.fontWeight.bold,
  },
});