import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, ActivityIndicator } from 'react-native';

import theme from '../styles/theme';
import globalStyles from '../styles/globalStyles';
import ProductCard from '../components/ProductCard';
import { fetchProducts } from '../services/productService';

// ---------------- Local product lists ----------------

const stitchedProducts = [
  {
    id: 'stitched-1',
    name: 'Classic Black Kurta Shalwar',
    price: 4299,
    image:
      'https://amanclothing.com.pk/cdn/shop/files/Stitched-Kurta-Shalwar-With-Contrast-Detailing-for-Men-Black-A-Man-32144674193576.jpg?v=1769086233',
    description:
      'Elegant black stitched outfit with a stand collar, contrast detailing and full sleeves. Suitable for casual and semi-formal wear.',
  },
  {
    id: 'stitched-2',
    name: 'Charcoal Grey Kameez Shalwar',
    price: 4299,
    image:
      'https://amanclothing.com.pk/cdn/shop/files/Stitched-Collar-Kameez-Shalwar-for-Men-Charcoal-Grey-A-Man-34156065063080.jpg?v=1769086075',
    description:
      'Charcoal grey outfit with a classic collar and neat contrast details. A smart option for everyday wear.',
  },
  {
    id: 'stitched-3',
    name: 'Cream Embroidered Kurta',
    price: 4557,
    image:
      'https://amanclothing.com.pk/cdn/shop/files/Stitched-Elegant-Boski-Embroidered-Kurta-With-Matching-Shalwar-for-Men-Cream-A-Man-33609100230824.jpg?v=1769086104',
    description:
      'Cream-coloured kurta with delicate embroidery and matching shalwar. Ideal for family gatherings and formal occasions.',
  },
  {
    id: 'stitched-4',
    name: 'Emerald Green Kameez Shalwar',
    price: 4299,
    image:
      'https://amanclothing.com.pk/cdn/shop/files/Stitched-Collar-Kameez-Shalwar-for-Men-Emerald-Green-A-Man-36146162860200.jpg?v=1769086104',
    description:
      'Deep green stitched outfit with a classic collar and simple detailing. A stylish choice for everyday and evening wear.',
  },
  {
    id: 'stitched-5',
    name: 'Navy Blue Formal Kurta',
    price: 4299,
    image:
      'https://amanclothing.com.pk/cdn/shop/files/Stitched-Regal-Collar-Kameez-Shalwar-With-Golden-Detailing-for-Men-Navy-Blue-A-Man-33609040265384.jpg?v=1769086133',
    description:
      'Navy blue kameez shalwar with golden detailing and a traditional collar. Suitable for festive and formal wear.',
  },
  {
    id: 'stitched-6',
    name: 'Fern Green Ban Collar Kurta',
    price: 4299,
    image:
      'https://amanclothing.com.pk/cdn/shop/files/Stitched-Full-Ban-Kurta-Shalwar-With-Golden-Accents-for-Men-Fern-Green-A-Man-34830041874600.jpg?v=1769086176',
    description:
      'Fern green outfit featuring a ban collar and golden accents. A traditional design with a modern appearance.',
  },
];

const unstitchedProducts = [
  {
    id: 'unstitched-1',
    name: 'Navy Blue Unstitched Fabric',
    price: 2499,
    image:
      'https://shopatjamdani.com/cdn/shop/files/jamdani-navy-blue-unstitched-fabric.png?v=1790405774&width=1200',
    description: 'Navy blue unstitched fabric for men.',
    fabric: 'Unstitched fabric',
    colour: 'Navy Blue',
    type: 'Unstitched fabric',
    length: '4.5 metres',
  },
  {
    id: 'unstitched-2',
    name: 'Grey Check Unstitched Fabric',
    price: 2999,
    image:
      'https://shopatjamdani.com/cdn/shop/files/jamdani-grey-check-unstitched-fabric.png?v=1790405672&width=1200',
    description: 'Grey checked unstitched fabric for men.',
    fabric: 'Unstitched fabric',
    colour: 'Grey',
    type: 'Unstitched fabric',
    length: '4.5 metres',
  },
  {
    id: 'unstitched-3',
    name: 'Light Grey Unstitched Fabric',
    price: 2799,
    image:
      'https://shopatjamdani.com/cdn/shop/files/jamdani-light-grey-unstitched-fabric.png?v=1790406046&width=1200',
    description: 'Light grey unstitched fabric for men.',
    fabric: 'Unstitched fabric',
    colour: 'Light Grey',
    type: 'Unstitched fabric',
    length: '4.5 metres',
  },
  {
    id: 'unstitched-4',
    name: 'Charcoal Unstitched Fabric',
    price: 2699,
    image:
      'https://shopatjamdani.com/cdn/shop/files/jamdani-charcoal-pinstripe-unstitched-fabric.png?v=1790405880&width=1200',
    description: 'Charcoal pinstripe unstitched fabric for men.',
    fabric: 'Unstitched fabric',
    colour: 'Charcoal',
    type: 'Unstitched fabric',
    length: '4.5 metres',
  },
  {
    id: 'unstitched-5',
    name: 'Champagne Beige Unstitched Fabric',
    price: 2899,
    image:
      'https://shopatjamdani.com/cdn/shop/files/ChatGPTImageSep17_2026at12_35_05AM.png?v=1789674956&width=1200',
    description: 'Champagne beige unstitched fabric for men.',
    fabric: 'Unstitched fabric',
    colour: 'Champagne Beige',
    type: 'Unstitched fabric',
    length: '4.5 metres',
  },
  {
    id: 'unstitched-6',
    name: 'Ivory Boski Unstitched Fabric',
    price: 3099,
    image:
      'https://shopatjamdani.com/cdn/shop/files/jamdani-boski-unstitched-fabric.png?v=1790406454&width=1200',
    description: 'Ivory boski unstitched fabric for men.',
    fabric: 'Unstitched fabric',
    colour: 'Ivory',
    type: 'Unstitched fabric',
    length: '4.5 metres',
  },
];

const womenStitchedProducts = [
  {
    id: 'women-stitched-1',
    name: 'Printed Lawn Suit',
    price: 3499,
    image: require('../assets/images/women-stitched-1.jpeg'),
    description: 'Beautiful printed stitched lawn suit for women.',
  },
  {
    id: 'women-stitched-2',
    name: 'Embroidered 3-Piece Suit',
    price: 4999,
    image: require('../assets/images/women-stitched-2.jpeg'),
    description: 'Elegant embroidered stitched suit for women.',
  },
  {
    id: 'women-stitched-3',
    name: 'Casual Summer Dress',
    price: 2999,
    image: require('../assets/images/women-stitched-3.jpeg'),
    description: 'Comfortable dress for everyday wear.',
  },
  {
    id: 'women-stitched-4',
    name: 'Formal Embroidered Suit',
    price: 5999,
    image: require('../assets/images/women-stitched-4.jpeg'),
    description: 'Beautiful formal outfit for special occasions.',
  },
];

const womenUnstitchedProducts = [
  {
    id: 'women-unstitched-1',
    name: 'Printed Lawn Fabric',
    price: 2499,
    image: require('../assets/images/women-unstitched-1.jpg'),
    description: 'Printed lawn fabric for a custom stitched outfit.',
  },
  {
    id: 'women-unstitched-2',
    name: 'Embroidered Lawn Fabric',
    price: 3999,
    image: require('../assets/images/women-unstitched-2.jpg'),
    description: 'Elegant embroidered unstitched lawn fabric.',
  },
  {
    id: 'women-unstitched-3',
    name: 'Cotton Unstitched Suit',
    price: 2799,
    image: require('../assets/images/women-unstitched-3.jpg'),
    description: 'Soft cotton fabric for everyday wear.',
  },
  {
    id: 'women-unstitched-4',
    name: 'Chiffon Unstitched Suit',
    price: 4499,
    image: require('../assets/images/women-unstitched-4.jpg'),
    description: 'Lightweight chiffon fabric for formal wear.',
  },
];

// Accessories: key = `${audience}-${subcategory}`

const accessoryProducts = {
   'Men-Purses/Wallets': [
    {
      id: 'men-wallet-1',
      name: 'Premium Leather Wallet',
      price: 1499,
       image: 'https://images.unsplash.com/photo-1627123424574-724758594e93?w=500',
      description: 'Premium leather wallet with a classic design for everyday use.',
    },
    {
      id: 'men-wallet-2',
      name: 'Slim Card Holder',
      price: 999,
           image: 'https://images.pexels.com/photos/27467357/pexels-photo-27467357.jpeg?auto=compress&cs=tinysrgb&w=500',
      description: 'A compact and lightweight wallet for carrying your essential cards.',
    },
    {
      id: 'men-wallet-3',
      name: 'Classic Black Wallet',
      price: 1799,
      image: 'https://images.pexels.com/photos/12495669/pexels-photo-12495669.jpeg?auto=compress&cs=tinysrgb&w=500',
      description: 'A sleek black wallet with a timeless look, perfect for daily use.',
    },
  ],
  'Men-Watches': [
    {
      id: 'men-watch-1',
      name: 'Classic Wrist Watch',
      price: 2499,
       image: 'https://images.pexels.com/photos/30508184/pexels-photo-30508184.jpeg?auto=compress&cs=tinysrgb&w=500',
      description: 'Classic watch for everyday style.',
    },
    {
      id: 'men-watch-2',
      name: 'Formal Steel Watch',
      price: 3299,
      image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500',
      description: 'A smart steel watch for formal occasions.',
    },
     {
    id: 'men-watch-3',
    name: 'Premium Green Watch',
    price: 3999,
    image: 'https://images.pexels.com/photos/13590312/pexels-photo-13590312.jpeg?auto=compress&cs=tinysrgb&w=500',
    description: 'Elegant watch with a green strap and silver dial.',
  },
  ],
  'Women-Jewellery': [
    {
      id: 'women-jewellery-1',
      name: 'Fashion Jewellery Set',
      price: 1599,
      image: 'https://images.unsplash.com/photo-1611652022419-a9419f74343d?w=500',
      description: 'Beautiful jewellery to complete your look.',
    },
    {
      id: 'women-jewellery-2',
      name: 'Traditional Earingd',
      price: 2199,
         image: 'https://images.pexels.com/photos/10983783/pexels-photo-10983783.jpeg?auto=compress&cs=tinysrgb&w=500',
      description: 'A traditional earings for weddings and festive days.',
    },
    {
    id: 'women-jewellery-3',
    name: 'Elegant Gold Bracelet',
    price: 999,
    image: 'https://images.pexels.com/photos/1191531/pexels-photo-1191531.jpeg?auto=compress&cs=tinysrgb&w=500',
    description: 'A simple bracelet for everyday styling.',
  },

  ],
  'Women-Purses': [
  {
    id: 'women-purse-1',
    name: 'Elegant Handbag',
    price: 2999,
    image: 'https://images.pexels.com/photos/1152077/pexels-photo-1152077.jpeg?auto=compress&cs=tinysrgb&w=500',
    description: 'An elegant handbag for everyday outfits.',
  },
  {
    id: 'women-purse-2',
    name: 'Evening Clutch',
    price: 1799,
    image: 'https://images.pexels.com/photos/904350/pexels-photo-904350.jpeg?auto=compress&cs=tinysrgb&w=500',
    description: 'A stylish clutch for parties and special events.',
  },
  {
    id: 'women-purse-3',
    name: 'Classic Shoulder Bag',
    price: 2499,
    image: 'https://images.pexels.com/photos/22432980/pexels-photo-22432980.jpeg?auto=compress&cs=tinysrgb&w=500',
    description: 'A classic shoulder bag for daily use.',
  },
  {
    id: 'women-purse-4',
    name: 'Mini Crossbody Bag',
    price: 1999,
     image: 'https://images.pexels.com/photos/22434773/pexels-photo-22434773.jpeg?auto=compress&cs=tinysrgb&w=500',
    description: 'A compact crossbody bag for outings and shopping.',
  },
],
};

const makeupProducts = [
  {
    id: 'makeup-1',
    name: 'Lipstick',
    price: 1299,
    image: 'https://images.unsplash.com/photo-1586495777744-4413f21062fa?w=500',
    description: 'A beautiful lipstick for your everyday look.',
  },
  {
    id: 'makeup-2',
    name: 'Makeup Brush Set',
    price: 1899,
    image: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=500',
    description: 'Brushes for smooth and easy makeup application.',
  },
  {
    id: 'makeup-3',
    name: 'Makeup Palette',
    price: 2199,
    image: 'https://images.unsplash.com/photo-1512496015851-a90fb38ba796?w=500',
    description: 'A versatile palette for different makeup looks.',
  },
  {
    id: 'makeup-4',
    name: 'Beauty Essentials',
    price: 1599,
    image: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=500',
    description: 'Beauty essentials for your makeup collection.',
  },
];

// ---------------- Screen ----------------

export default function ProductScreen({ route, navigation }) {
  const category = route.params?.category || 'Accessories';
  const audience = route.params?.audience || 'All';
  const subcategory = route.params?.subcategory;

  const isMen = category === 'Clothes' && audience === 'Men';
  const isWomen = category === 'Clothes' && audience === 'Women';
  const isMakeup = category === 'Makeup';

  // Men's shirts come from https://fakestoreapi.com/products
  const useAPI = isMen && subcategory === 'Shirts';

  const [apiProducts, setApiProducts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    if (!useAPI) {
      setApiProducts([]);
      setError(''); 
      setLoading(false);
      return;
    }
// Api dATA FETCH
    async function loadProducts() {
      try {
        setLoading(true);
        setError('');
        const data = await fetchProducts("men's clothing");
        setApiProducts(data);
      } catch (err) {
        setError('Could not load products. Please check your internet and try again.');
      } finally {
        setLoading(false);
      }
    }

    loadProducts();
  }, [useAPI, reloadKey]);

  let items = [];

  if (useAPI) {
    items = apiProducts;
  } else if (isMakeup) {
    items = makeupProducts;
  } else if (category === 'Accessories') {
    items = accessoryProducts[`${audience}-${subcategory}`] || [];
  } else if (isMen && subcategory === 'Stitched') {
    items = stitchedProducts;
  } else if (isMen && subcategory === 'Unstitched') {
    items = unstitchedProducts;
  } else if (isWomen && subcategory === 'Stitched') {
    items = womenStitchedProducts;
  } else if (isWomen && subcategory === 'Unstitched') {
    items = womenUnstitchedProducts;
  }

  if (useAPI && loading) {
    return (
      <View style={globalStyles.container}>
        <ActivityIndicator size="large" color={theme.colors.primary} style={styles.loader} />
        <Text style={styles.centerText}>Loading products...</Text>
      </View>
    );
  }

  if (useAPI && error) {
    return (
      <View style={globalStyles.container}>
        <Text style={styles.centerText}>{error}</Text>

        <TouchableOpacity
          style={[globalStyles.button, styles.retryButton]}
          onPress={() => setReloadKey((current) => current + 1)}
        >
          <Text style={globalStyles.buttonText}>Try Again</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const heading = isMakeup
    ? 'Makeup Collection'
    : `${audience} ${subcategory || ''} Collection`.replace('  ', ' ');

  const openDetails = (item) =>
    navigation.navigate('ProductDetails', {
      product: item,
      category,
      audience,
      subcategory,
    });

  return (
    <ScrollView style={globalStyles.container} showsVerticalScrollIndicator={false}>
      <View style={globalStyles.pageHeader}>
        <Text style={globalStyles.pageBrand}>Rang-e-Riwaaj</Text>
        <Text style={globalStyles.pageTitle}>{heading}</Text>
        <Text style={[globalStyles.pageSubtitle, styles.headerSubtitle]}>
          {items.length} product(s) • {category}
        </Text>
      </View>

      {items.length === 0 ? (
        <Text style={styles.centerText}>No products found in this section yet.</Text>
      ) : (
        <View style={styles.grid}>
          {items.map((item) => (
            <ProductCard key={String(item.id)} product={item} onPress={() => openDetails(item)} />
          ))}
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  loader: { marginTop: theme.spacing.xl },
  centerText: {
    textAlign: 'center',
    margin: theme.spacing.large,
    color: theme.colors.text,
  },
  retryButton: { marginHorizontal: theme.spacing.section },
  headerSubtitle: {
    fontSize: theme.fontSize.small,
    marginTop: theme.spacing.small,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    paddingHorizontal: theme.spacing.medium,
    paddingVertical: theme.spacing.screen,
  },
});