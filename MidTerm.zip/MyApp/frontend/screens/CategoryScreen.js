import React from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import theme from '../styles/theme';
import globalStyles from '../styles/globalStyles';

// First level: tabs on this screen
const categoryData = {
  Accessories: [
    {
      title: 'Men',
      subtitle: 'Wallets, Purses & Watches',
      image: require('../assets/images/watch.jpg'),
    },
    {
      title: 'Women',
      subtitle: 'Jewellery & Purses',
      image: require('../assets/images/jewellery.jpeg'),
    },
  ],
  Clothes: [
    {
      title: 'Men',
      subtitle: 'Stitched & Unstitched',
      image: require('../assets/images/men-clothes.jpeg'),
    },
    {
      title: 'Women',
      subtitle: 'Stitched & Unstitched',
      image: require('../assets/images/women-clothes.jpeg'),
    },
  ],
  Makeup: [
    {
      title: 'Beauty Products',
      subtitle: 'Explore makeup & beauty',
      image: require('../assets/images/makeup.jpg'),
    },
  ],
};

// Second level: further categories for Men / Women
// (items without an image show an icon instead)
const subCategoryData = {
  'Accessories-Men': [
    { title: 'Purses/Wallets',
       subtitle: 'Wallets & purses for men', 
      image: require('../assets/images/wallet.jpeg'),
    },
    {
      title: 'Watches',
      subtitle: 'Classic & modern watches',
      image: require('../assets/images/watch.jpg'),
    },
  ],
  'Accessories-Women': [
    {
      title: 'Jewellery',
      subtitle: 'Necklaces, rings & more',
      image: require('../assets/images/jewellery.jpeg'),
    },
    { 
      title: 'Purses', 
      subtitle: 'Handbags & purses', 
      image: require('../assets/images/purse.jpeg'),
    },
  ],
  'Clothes-Men': [
    {
      title: 'Shirts',
      subtitle: 'Explore shirts collection',
      image: require('../assets/images/men-shirt.jpg'),
    },
    {
      title: 'Stitched',
      subtitle: 'Ready-made clothing',
      image: require('../assets/images/men-stitched.jpg'),
    },
    {
      title: 'Unstitched',
      subtitle: 'Fabric & unstitched suits',
      image: require('../assets/images/men-unstitched.jpg'),
    },
  ],
  'Clothes-Women': [
    {
      title: 'Stitched',
      subtitle: 'Ready-made suits & outfits',
      image: require('../assets/images/women-stitched.png'),
    },
    {
      title: 'Unstitched',
      subtitle: 'Fabric & unstitched suits',
      image: require('../assets/images/women-unstitched.jpg'),
    },
  ],
};

export default function CategoryScreen({ route, navigation }) {
  const selectedCategory = route.params?.category || 'Accessories';
  const audience = route.params?.audience;

  // We are on the second level when a category has Men/Women chosen
  const subKey = `${selectedCategory}-${audience}`;
  const isSubList = Boolean(audience && subCategoryData[subKey]);

  const options = isSubList
    ? subCategoryData[subKey]
    : categoryData[selectedCategory] || categoryData.Accessories;

  function handleCategoryPress(item) {
    // Second level -> open the products
    if (isSubList) {
      navigation.navigate('Products', {
        category: selectedCategory,
        audience,
        subcategory: item.title,
      });
      return;
    }

    // First level, Men/Women in Accessories or Clothes -> open the second level
    if (
      (selectedCategory === 'Clothes' || selectedCategory === 'Accessories') &&
      (item.title === 'Men' || item.title === 'Women')
    ) {
      navigation.navigate('CategoryList', {
        category: selectedCategory,
        audience: item.title,
      });
      return;
    }

    // Makeup -> open the products (fetched from the API)
    navigation.navigate('Products', {
      category: selectedCategory,
      audience: item.title,
    });
  }

  const sectionTitle = isSubList ? `${audience} ${selectedCategory}` : selectedCategory;

  return (
    <ScrollView style={globalStyles.container}>
      <View style={[globalStyles.pageHeader, styles.header]}>
        <Text style={globalStyles.pageBrand}>RANG-E-RIWAAJ</Text>
        <Text style={globalStyles.pageTitle}>
          {isSubList ? sectionTitle : 'Explore Collections'}
        </Text>
        <Text style={globalStyles.pageSubtitle}>
          {isSubList ? 'Choose your style' : 'Find your perfect style'}
        </Text>
      </View>

      {isSubList ? (
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <Text style={styles.backText}>‹  Back</Text>
        </TouchableOpacity>
      ) : (
        <View style={styles.tabs}>
          {Object.keys(categoryData).map((category) => (
            <TouchableOpacity
              key={category}
              style={[styles.tab, selectedCategory === category && styles.activeTab]}
              onPress={() => navigation.setParams({ category, audience: undefined })}
            >
              <Text
                style={[styles.tabText, selectedCategory === category && styles.activeTabText]}
              >
                {category}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      )}

      <Text style={styles.sectionTitle}>{sectionTitle}</Text>
      <Text style={[globalStyles.mutedText, styles.sectionSubtitle]}>
        Choose a collection to explore
      </Text>

      {options.map((item) => (
        <TouchableOpacity
          key={item.title}
          style={[globalStyles.card, globalStyles.row, styles.card]}
          activeOpacity={theme.opacity.pressed}
          onPress={() => handleCategoryPress(item)}
        >
          <View style={styles.imageBox}>
            {item.image ? (
              <Image source={item.image} style={styles.categoryImage} resizeMode="contain" />
            ) : (
              <Ionicons name={item.icon || 'bag-outline'} size={36} color={theme.colors.primary} />
            )}
          </View>

          <View style={styles.cardInfo}>
            <Text style={styles.cardTitle}>{item.title}</Text>
            <Text style={[globalStyles.mutedText, styles.cardSubtitle]}>{item.subtitle}</Text>
          </View>

          <Ionicons name="chevron-forward" size={24} color={theme.colors.primary} />
        </TouchableOpacity>
      ))}

      <View style={styles.footer}>
        <Text style={styles.footerText}>✨ Style that celebrates you ✨</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: theme.spacing.screen,
    paddingTop: theme.spacing.section,
    paddingBottom: theme.spacing.section,
    borderBottomLeftRadius: theme.spacing.section,
    borderBottomRightRadius: theme.spacing.section,
  },
  backButton: {
    paddingHorizontal: theme.spacing.screen,
    paddingTop: theme.spacing.medium,
  },
  backText: {
    color: theme.colors.primary,
    fontSize: theme.fontSize.medium,
    fontWeight: theme.fontWeight.semibold,
  },
  tabs: {
    flexDirection: 'row',
    marginHorizontal: theme.spacing.medium,
    marginTop: theme.spacing.screen,
    gap: theme.spacing.small,
  },
  tab: {
    flex: 1,
    paddingVertical: theme.spacing.medium,
    borderRadius: theme.radius.medium,
    backgroundColor: theme.colors.white,
    alignItems: 'center',
    borderWidth: theme.borderWidth.thin,
    borderColor: theme.colors.border,
  },
  activeTab: {
    backgroundColor: theme.colors.primary,
    borderColor: theme.colors.primary,
  },
  tabText: {
    color: theme.colors.text,
    fontSize: theme.fontSize.small,
    fontWeight: theme.fontWeight.medium,
  },
  activeTabText: { color: theme.colors.white },
  sectionTitle: {
    marginHorizontal: theme.spacing.screen,
    marginTop: theme.spacing.section,
    fontSize: theme.fontSize.xlarge,
    fontWeight: theme.fontWeight.bold,
    color: theme.colors.primary,
  },
  sectionSubtitle: {
    marginHorizontal: theme.spacing.screen,
    marginTop: theme.spacing.tiny,
    marginBottom: theme.spacing.medium,
    fontSize: theme.fontSize.compact,
  },
  card: {
    marginHorizontal: theme.spacing.screen,
    marginBottom: theme.spacing.medium,
    padding: theme.spacing.medium,
    borderRadius: theme.radius.medium,
  },
  imageBox: {
    width: 78,
    height: 78,
    borderRadius: theme.radius.medium,
    backgroundColor: theme.colors.softPink,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    flexShrink: 0,
  },
  categoryImage: {
    width: '100%',
    height: '100%',
  },
  cardInfo: {
    flex: 1,
    marginLeft: theme.spacing.medium,
  },
  cardTitle: {
    color: theme.colors.primary,
    fontSize: theme.fontSize.large,
    fontWeight: theme.fontWeight.bold,
  },
  cardSubtitle: { marginTop: theme.spacing.small },
  footer: {
    margin: theme.spacing.screen,
    marginTop: theme.spacing.medium,
    padding: theme.spacing.medium,
    backgroundColor: theme.colors.lightPink,
    borderRadius: theme.radius.medium,
    alignItems: 'center',
  },
  footerText: {
    color: theme.colors.primary,
    fontSize: theme.fontSize.compact,
    fontWeight: theme.fontWeight.medium,
  },
});