import React, { useEffect, useMemo, useState } from 'react';
import { View, Text, Image, StatusBar, StyleSheet, useWindowDimensions } from 'react-native';
import { useFonts } from 'expo-font';
import {
  PlayfairDisplay_700Bold,
  PlayfairDisplay_400Regular_Italic,
} from '@expo-google-fonts/playfair-display';
import { Poppins_400Regular, Poppins_500Medium } from '@expo-google-fonts/poppins';

import theme from '../styles/theme';
import globalStyles from '../styles/globalStyles';

const TILE = 64; // distance between diamond centres
const DIAMOND = Math.round(TILE * 0.7071); // side of the rotated square

// Faint diamond pattern that covers the whole background
function DiamondPattern({ width, height }) {
  const diamonds = useMemo(() => {
    const items = [];
    const rows = Math.ceil(height / (TILE / 2)) + 2;
    const cols = Math.ceil(width / TILE) + 2;

    for (let row = 0; row < rows; row += 1) {
      for (let col = 0; col < cols; col += 1) {
        items.push({
          key: `${row}-${col}`,
          left: col * TILE + (row % 2) * (TILE / 2) - TILE / 2 - DIAMOND / 2,
          top: row * (TILE / 2) - DIAMOND / 2,
        });
      }
    }
    return items;
  }, [width, height]);

  return (
    <View style={styles.pattern} pointerEvents="none">
      {diamonds.map((item) => (
        <View key={item.key} style={[styles.diamond, { left: item.left, top: item.top }]} />
      ))}
    </View>
  );
}

export default function SplashScreen({ navigation }) {
  const { width, height } = useWindowDimensions();
  const [activeDot, setActiveDot] = useState(0);

  const [fontsLoaded] = useFonts({
    PlayfairDisplay_700Bold,
    PlayfairDisplay_400Regular_Italic,
    Poppins_400Regular,
    Poppins_500Medium,
  });

  // Move to Home after the splash
  useEffect(() => {
    const timer = setTimeout(() => {
      navigation.replace('Home');
    }, 3000);
    return () => clearTimeout(timer);
  }, [navigation]);

  // Little loading dots at the bottom
  useEffect(() => {
    const dots = setInterval(() => setActiveDot((current) => (current + 1) % 3), 600);
    return () => clearInterval(dots);
  }, []);

  const archWidth = width * 0.78;

  // Until the custom fonts are ready, fall back to the system fonts
  const serifBold = fontsLoaded ? { fontFamily: theme.fonts.serifBold } : styles.fallbackBold;
  const serifItalic = fontsLoaded ? { fontFamily: theme.fonts.serifItalic } : styles.fallbackItalic;
  const sansMedium = fontsLoaded ? { fontFamily: theme.fonts.sansMedium } : null;

  return (
    <View style={[globalStyles.container, styles.container]}>
      <StatusBar backgroundColor={theme.colors.primary} barStyle="light-content" />

      <DiamondPattern width={width} height={height} />

      {/* Arch with logo, name and tagline */}
      <View
        style={[
          styles.arch,
          {
            width: archWidth,
            borderTopLeftRadius: archWidth / 2,
            borderTopRightRadius: archWidth / 2,
          },
        ]}
      >
        <View
          style={[
            styles.innerArch,
            {
              borderTopLeftRadius: archWidth / 2 - theme.spacing.medium,
              borderTopRightRadius: archWidth / 2 - theme.spacing.medium,
            },
          ]}
        />

        <View style={styles.halo}>
          <View style={styles.logoCircle}>
            {/* Put your logo at frontend/assets/images/logo.png */}
            <Image
              source={require('../assets/images/logo.png')}
              style={styles.logoImage}
              resizeMode="contain"
            />
          </View>
        </View>

        <Text style={[styles.appName, serifBold]} numberOfLines={1} adjustsFontSizeToFit>
          Rang-e-Riwaaj
        </Text>

        <View style={styles.divider} />

        <Text style={[styles.tagline, serifItalic]}>Your Style, Your Tradition</Text>
      </View>

      {/* Offer card */}
      <View style={[styles.offerCard, { width: archWidth }]}>
        <Text style={[styles.offerEyebrow, sansMedium]}>LIMITED OFFER</Text>
        <Text style={[styles.offerText, serifBold]}>20% OFF — Limited Stock!</Text>
      </View>

      {/* Footer */}
      <View style={styles.footer}>
        <Text style={[styles.footerText, sansMedium]}>FASHION  ◆  BEAUTY  ◆  ACCESSORIES</Text>

        <View style={styles.dots}>
          {[0, 1, 2].map((index) => (
            <View key={index} style={[styles.dot, index === activeDot && styles.activeDot]} />
          ))}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: theme.colors.primary,
    alignItems: 'center',
    overflow: 'hidden',
  },

  // Background pattern
  pattern: {
    ...StyleSheet.absoluteFillObject,
  },
  diamond: {
    position: 'absolute',
    width: DIAMOND,
    height: DIAMOND,
    borderWidth: theme.borderWidth.thin,
    borderColor: theme.colors.patternLine,
    transform: [{ rotate: '45deg' }],
  },

  // Arch
  arch: {
    marginTop: theme.spacing.xl * 2.5,
    paddingTop: theme.spacing.xl,
    paddingBottom: theme.spacing.xl,
    paddingHorizontal: theme.spacing.medium,
    alignItems: 'center',
    borderWidth: theme.borderWidth.medium,
    borderColor: theme.colors.gold,
  },
  innerArch: {
    position: 'absolute',
    top: theme.spacing.medium,
    left: theme.spacing.medium,
    right: theme.spacing.medium,
    bottom: 0,
    borderWidth: theme.borderWidth.thin,
    borderBottomWidth: 0,
    borderColor: theme.colors.gold,
    opacity: 0.6,
  },
  halo: {
    width: 136,
    height: 136,
    borderRadius: theme.radius.round,
    backgroundColor: theme.colors.halo,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoCircle: {
    width: 112,
    height: 112,
    borderRadius: theme.radius.round,
    backgroundColor: theme.colors.background,
    borderWidth: theme.borderWidth.thick,
    borderColor: theme.colors.gold,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  logoImage: {
    width: 76,
    height: 76,
  },
  appName: {
    color: theme.colors.white,
    fontSize: theme.fontSize.display + 6,
    marginTop: theme.spacing.large,
    textAlign: 'center',
    alignSelf: 'stretch',
  },
  divider: {
    width: 60,
    height: theme.borderWidth.medium,
    backgroundColor: theme.colors.gold,
    marginTop: theme.spacing.medium,
  },
  tagline: {
    color: theme.colors.lightGold,
    fontSize: theme.fontSize.body,
    marginTop: theme.spacing.medium,
    textAlign: 'center',
  },

  // Offer card
  offerCard: {
    marginTop: theme.spacing.xl + theme.spacing.large,
    backgroundColor: theme.colors.background,
    borderWidth: theme.borderWidth.thin,
    borderColor: theme.colors.gold,
    borderRadius: theme.radius.large,
    paddingVertical: theme.spacing.medium,
    paddingHorizontal: theme.spacing.large,
    alignItems: 'center',
  },
  offerEyebrow: {
    color: theme.colors.gold,
    fontSize: theme.fontSize.caption,
    letterSpacing: theme.letterSpacing.medium,
  },
  offerText: {
    color: theme.colors.primary,
    fontSize: theme.fontSize.heading,
    textAlign: 'center',
    marginTop: theme.spacing.small,
  },

  // Footer
  footer: {
    position: 'absolute',
    bottom: theme.spacing.xl,
    alignItems: 'center',
  },
  footerText: {
    color: theme.colors.lightGold,
    fontSize: theme.fontSize.caption,
    letterSpacing: theme.letterSpacing.medium,
  },
  dots: {
    flexDirection: 'row',
    gap: theme.spacing.small,
    marginTop: theme.spacing.medium,
  },
  dot: {
    width: theme.spacing.small,
    height: theme.spacing.small,
    borderRadius: theme.radius.round,
    backgroundColor: theme.colors.dotFaded,
  },
  activeDot: {
    width: theme.spacing.large - 2,
    backgroundColor: theme.colors.gold,
  },

  // Used only while the custom fonts are still loading
  fallbackBold: { fontWeight: theme.fontWeight.bold },
  fallbackItalic: { fontStyle: 'italic' },
});