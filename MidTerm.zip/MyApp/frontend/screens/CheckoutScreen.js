import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Alert, ScrollView } from 'react-native';

import theme from '../styles/theme';
import globalStyles from '../styles/globalStyles';
import { useCart } from '../services/CartContext';

export default function CheckoutScreen({ navigation }) {
  const { cartItems, clearCart } = useCart();
// Discount Calculation
  const subtotal = cartItems.reduce(
    (total, item) => total + Number(item.price) * item.quantity,
    0
  );
   const discount = subtotal > 1200 ? Math.round(subtotal * 0.2) : 0;
  const total = subtotal - discount;

   const money = (value) =>
    value.toLocaleString('en-PK', { maximumFractionDigits: 0 });1

  function placeOrder() {
    if (cartItems.length === 0) {
      Alert.alert('Empty Cart', 'Please add products first.');
      return;
    }

    Alert.alert(
      'Order Placed!',
      `Your order total is Rs. ${money(total)}. Thank you for shopping with Rang-e-Riwaaj!`,
      [
        {
          text: 'OK',
          onPress: () => {
            clearCart();
            navigation.navigate('Home', { screen: 'Shop' });
          },
        },
      ]
    );
  }

  return (
    <ScrollView style={globalStyles.container}>
      <View style={[globalStyles.pageHeader, styles.header]}>
        <Text style={globalStyles.pageBrand}>RANG-E-RIWAAJ</Text>
        <Text style={globalStyles.pageTitle}>Checkout</Text>
        <Text style={[globalStyles.pageSubtitle, styles.subtitle]}>Review your order</Text>
      </View>

      <View style={[globalStyles.card, styles.card]}>
        <Text style={styles.sectionTitle}>Order Summary</Text>

        {cartItems.map((item) => (
          <View key={String(item.id)} style={[globalStyles.rowBetween, styles.itemRow]}>
            <Text style={styles.itemName}>
              {item.name || item.title} × {item.quantity}
            </Text>
            <Text style={styles.amount}>
              Rs. {money(Number(item.price) * item.quantity)}
            </Text>
          </View>
        ))}

        <View style={[globalStyles.divider, styles.divider]} />

        <View style={[globalStyles.rowBetween, styles.row]}>
          <Text style={styles.label}>Subtotal</Text>
          <Text style={styles.amount}>Rs. {money(subtotal)}</Text>
        </View>

        <View style={[globalStyles.rowBetween, styles.row]}>
          <Text style={styles.label}>Discount (20%)</Text>
          <Text style={styles.discount}>− Rs. {money(discount)}</Text>
        </View>

        <Text style={styles.note}>
          {subtotal > 1200
            ? '🎉 You unlocked your 20% discount!'
            : 'Shop above Rs. 1,200 to unlock 20% off.'}
        </Text>

        <View style={[globalStyles.divider, styles.divider]} />

        <View style={[globalStyles.rowBetween, styles.row]}>
          <Text style={styles.totalLabel}>Final Total</Text>
          <Text style={styles.totalAmount}>Rs. {money(total)}</Text>
        </View>
      </View>

      <TouchableOpacity
        style={[globalStyles.button, styles.button]}
        activeOpacity={theme.opacity.pressed}
        onPress={placeOrder}
      >
        <Text style={styles.buttonText}>PLACE ORDER ✓</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
        <Text style={styles.backText}>Back to Cart</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingTop: theme.spacing.xl,
    borderBottomLeftRadius: theme.radius.large,
    borderBottomRightRadius: theme.radius.large,
  },
  subtitle: { fontSize: theme.fontSize.body, marginTop: theme.spacing.tiny },
  card: {
    margin: theme.spacing.medium,
    padding: theme.spacing.medium,
    borderRadius: theme.radius.medium,
  },
  sectionTitle: {
    color: theme.colors.primary,
    fontSize: theme.fontSize.subheading,
    fontWeight: theme.fontWeight.bold,
    marginBottom: theme.spacing.medium,
  },
  itemRow: {
    marginBottom: theme.spacing.medium,
    gap: theme.spacing.medium,
  },
  itemName: {
    flex: 1,
    color: theme.colors.text,
    fontSize: theme.fontSize.compact,
  },
  amount: {
    color: theme.colors.text,
    fontSize: theme.fontSize.compact,
    fontWeight: theme.fontWeight.medium,
  },
  divider: { marginVertical: theme.spacing.medium },
  row: { marginVertical: theme.spacing.small },
  label: {
    color: theme.colors.muted,
    fontSize: theme.fontSize.regular,
  },
  discount: {
    color: theme.colors.success,
    fontWeight: theme.fontWeight.bold,
  },
  note: {
    color: theme.colors.primary,
    fontSize: theme.fontSize.small,
    marginTop: theme.spacing.medium,
  },
  totalLabel: {
    color: theme.colors.text,
    fontSize: theme.fontSize.large,
    fontWeight: theme.fontWeight.bold,
  },
  totalAmount: {
    color: theme.colors.primary,
    fontSize: theme.fontSize.subheading,
    fontWeight: theme.fontWeight.black,
  },
  button: {
    marginHorizontal: theme.spacing.medium,
    padding: theme.spacing.medium,
  },
  buttonText: {
    color: theme.colors.white,
    fontSize: theme.fontSize.medium,
    fontWeight: theme.fontWeight.bold,
  },
  backButton: {
    alignItems: 'center',
    padding: theme.spacing.medium,
    marginBottom: theme.spacing.screen,
  },
  backText: {
    color: theme.colors.primary,
    fontWeight: theme.fontWeight.bold,
  },
});