import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import theme from '../styles/theme';
import globalStyles from '../styles/globalStyles';
import { useAuth } from '../services/AuthContext';

function MenuRow({ icon, label, onPress }) {
  return (
    <TouchableOpacity style={[globalStyles.row, styles.menuRow]} onPress={onPress}>
      <Ionicons name={icon} size={23} color={theme.colors.primary} />
      <Text style={styles.menuText}>{label}</Text>
      <Ionicons name="chevron-forward" size={20} color={theme.colors.iconMuted} />
    </TouchableOpacity>
  );
}

export default function ProfileScreen({ navigation }) {
  const { user, logout } = useAuth();

  const openAuth = (mode) =>
    navigation.navigate('Auth', { returnToProfile: true, mode });

  async function handleLogout() {
    await logout();
    Alert.alert('Logged out', 'You have been logged out successfully.');
  }

  return (
    <ScrollView
      style={globalStyles.container}
      contentContainerStyle={[globalStyles.screenContent, styles.content]}
      showsVerticalScrollIndicator={false}
    >
      <Text style={styles.heading}>My Profile</Text>
      <Text style={[globalStyles.mutedText, styles.subtitle]}>
        Your personal space at Rang-e-Riwaaj
      </Text>

      <View style={[globalStyles.card, globalStyles.centered, styles.profileCard]}>
        <View style={styles.avatar}>
          <Ionicons name="person-outline" size={42} color={theme.colors.primary} />
        </View>

        {user ? (
          <>
            <Text style={styles.welcome}>Hello, {user.name || 'Shopper'}!</Text>
            <Text style={[globalStyles.mutedText, styles.description]}>{user.email}</Text>

            <TouchableOpacity
              style={[globalStyles.secondaryButton, styles.fullWidth]}
              onPress={handleLogout}
            >
              <Text style={globalStyles.secondaryButtonText}>Logout</Text>
            </TouchableOpacity>
          </>
        ) : (
          <>
            <Text style={styles.welcome}>Welcome to Rang-e-Riwaaj!</Text>

            <Text style={[globalStyles.mutedText, styles.description]}>
              Sign in or create an account to manage your profile, orders and shopping
              preferences.
            </Text>

            <TouchableOpacity
              style={[globalStyles.button, styles.fullWidth]}
              onPress={() => openAuth('login')}
            >
              <Text style={globalStyles.buttonText}>Login</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[globalStyles.secondaryButton, styles.fullWidth, styles.secondaryGap]}
              onPress={() => openAuth('signup')}
            >
              <Text style={globalStyles.secondaryButtonText}>Create Account</Text>
            </TouchableOpacity>
          </>
        )}
      </View>

      
    
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: theme.spacing.xl },
  heading: {
    fontSize: theme.fontSize.xlarge,
    fontWeight: theme.fontWeight.bold,
    color: theme.colors.primary,
  },
  subtitle: {
    fontSize: theme.fontSize.compact,
    marginTop: theme.spacing.small,
    marginBottom: theme.spacing.large,
  },
  profileCard: {
    borderRadius: theme.radius.large,
    padding: theme.spacing.screen,
  },
  avatar: {
    width: 85,
    height: 85,
    borderRadius: theme.radius.round,
    backgroundColor: theme.colors.lightPink,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: theme.spacing.medium,
  },
  welcome: {
    fontSize: theme.fontSize.subheading,
    fontWeight: theme.fontWeight.bold,
    color: theme.colors.primary,
    textAlign: 'center',
  },
  description: {
    fontSize: theme.fontSize.compact,
    lineHeight: theme.lineHeight.regular,
    textAlign: 'center',
    marginTop: theme.spacing.small,
    marginBottom: theme.spacing.screen,
  },
  fullWidth: { width: '100%' },
  secondaryGap: { marginTop: theme.spacing.medium },
  sectionTitle: {
    fontSize: theme.fontSize.subheading,
    fontWeight: theme.fontWeight.bold,
    color: theme.colors.text,
    marginTop: theme.spacing.section,
    marginBottom: theme.spacing.medium,
  },
  menuCard: {
    padding: 0,
    paddingHorizontal: theme.spacing.medium,
  },
  menuRow: {
    paddingVertical: theme.spacing.medium,
    gap: theme.spacing.medium,
  },
  menuText: {
    flex: 1,
    fontSize: theme.fontSize.regular,
    color: theme.colors.text,
  },
});