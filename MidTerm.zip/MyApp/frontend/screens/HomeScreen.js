import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  ScrollView,
  TouchableOpacity,
  Image,
  ImageBackground,
  StyleSheet,
  StatusBar,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import theme from '../styles/theme';
import globalStyles from '../styles/globalStyles';
import MovingBanner from '../components/MovingBanner';

const categories = [
  {
    name: 'Accessories',
    image: require('../assets/images/accessories.jpg'),
    description: 'Jewellery, watches & more',
    keywords: 'watch wallet jewellery purse handbag accessories men women',
  },
  {
    name: 'Clothes',
    image: require('../assets/images/clothes.jpg'),
    description: 'Stitched & unstitched',
    keywords: 'kurta shalwar kameez lawn suit dress fabric stitched unstitched shirt men women',
  },
  {
    name: 'Makeup',
    image: require('../assets/images/makeupp.jpg'),
    description: 'Beauty picks for you',
    keywords: 'lipstick brush palette beauty cosmetics',
  },
];

function CategoryCard({ category, onPress }) {
  return (
    <TouchableOpacity
      activeOpacity={theme.opacity.pressed}
      style={[globalStyles.card, globalStyles.row, styles.categoryCard]}
      onPress={onPress}
    >
      <View style={styles.categoryIconBox}>
        <Image source={category.image} style={styles.categoryImage} resizeMode="cover" />
      </View>

      <View style={styles.categoryInfo}>
        <Text style={styles.categoryName}>{category.name}</Text>
        <Text style={[globalStyles.mutedText, styles.categoryDescription]}>
          {category.description}
        </Text>
      </View>

      <Ionicons name="chevron-forward" size={24} color={theme.colors.primary} />
    </TouchableOpacity>
  );
}

export default function HomeScreen({ navigation }) {
  const [search, setSearch] = useState('');

  const query = search.trim().toLowerCase();

  const filteredCategories = categories.filter((category) =>
    [category.name, category.description, category.keywords].some((text) =>
      text.toLowerCase().includes(query)
    )
  );

  const openCategory = (name) => navigation.navigate('Categories', { category: name });

  return (
    <View style={globalStyles.container}>
      <StatusBar backgroundColor={theme.colors.background} barStyle="dark-content" />

      <ScrollView showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
        <View style={[globalStyles.rowBetween, styles.header]}>
          <View>
            <Text style={styles.greeting}>WELCOME TO</Text>
            <Text style={styles.brand}>Rang-e-Riwaaj</Text>
        
          </View>

          <TouchableOpacity style={styles.cartButton} onPress={() => navigation.navigate('Cart')}>
            <Ionicons name="bag-handle-outline" size={24} color={theme.colors.primary} />
          </TouchableOpacity>
        </View>

        <View style={[globalStyles.input, globalStyles.row, styles.searchBox]}>
          <Ionicons name="search" size={20} color={theme.colors.primary} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search clothes, makeup..."
            placeholderTextColor={theme.colors.placeholder}
            value={search}
            onChangeText={setSearch}
          />
        </View>

        {query === '' ? (
          <>
            <MovingBanner />

            {/* Poster below the moving banner */}
            <TouchableOpacity
              activeOpacity={theme.opacity.soft}
              style={styles.posterWrap}
              onPress={() => openCategory('Clothes')}
            >
              <ImageBackground
                source={require('../assets/images/clothes.jpg')}
                style={styles.poster}
                imageStyle={styles.posterImage}
                resizeMode="cover"
              >
                <View style={styles.posterOverlay}>
                  <Text style={styles.posterEyebrow}>THE FESTIVE EDIT</Text>
                  <Text style={styles.posterTitle}>Style for every occasion</Text>
                  <View style={styles.posterButton}>
                    <Text style={styles.posterButtonText}>Shop Now</Text>
                  </View>
                </View>
              </ImageBackground>
            </TouchableOpacity>

            <View style={[globalStyles.rowBetween, styles.sectionHeader]}>
              <View>
                <Text style={styles.sectionTitle}>Shop by Category</Text>
                <Text style={[globalStyles.mutedText, styles.sectionSubtitle]}>
                  For Men & Women
                </Text>
              </View>
              <Ionicons name="flower-outline" size={30} color={theme.colors.gold} />
            </View>

            {categories.map((category) => (
              <CategoryCard
                key={category.name}
                category={category}
                onPress={() => openCategory(category.name)}
              />
            ))}

            <View style={styles.noteBox}>
              <Text style={styles.noteTitle}>Har Rang, Har Andaaz ♡</Text>
              <Text style={styles.noteText}>From everyday desi wear to festive charm.</Text>
            </View>
          </>
        ) : (
          <>
            <Text style={styles.resultsTitle}>
              {filteredCategories.length > 0 ? `Results for "${search.trim()}"` : 'No results'}
            </Text>

            {filteredCategories.map((category) => (
              <CategoryCard
                key={category.name}
                category={category}
                onPress={() => openCategory(category.name)}
              />
            ))}

            {filteredCategories.length === 0 && (
              <View style={styles.noResults}>
                <Text style={styles.noResultsText}>
                  Nothing found for "{search.trim()}". Try watch, kurta, lawn or lipstick.
                </Text>
              </View>
            )}
          </>
        )}

        <View style={globalStyles.bottomSpace} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: theme.spacing.screen,
    paddingTop: theme.spacing.large,
    paddingBottom: theme.spacing.medium,
  },
  greeting: {
    color: theme.colors.gold,
    fontSize: theme.fontSize.caption,
    fontWeight: theme.fontWeight.bold,
    letterSpacing: theme.letterSpacing.small,
  },
  brand: {
    color: theme.colors.primary,
    fontSize: theme.fontSize.title,
    fontWeight: theme.fontWeight.black,
    marginTop: theme.spacing.tiny,
  },
  tagline: {
    color: theme.colors.text,
    fontSize: theme.fontSize.compact,
    fontStyle: 'italic',
    marginTop: theme.spacing.tiny,
  },
  cartButton: {
    width: 48,
    height: 48,
    borderRadius: theme.radius.round,
    backgroundColor: theme.colors.lightPink,
    alignItems: 'center',
    justifyContent: 'center',
  },
  searchBox: {
    marginHorizontal: theme.spacing.screen,
    marginBottom: theme.spacing.screen,
    paddingVertical: 0,
  },
  searchInput: {
    flex: 1,
    height: 48,
    marginLeft: theme.spacing.small,
    fontSize: theme.fontSize.regular,
    color: theme.colors.text,
  },

  // Poster
  posterWrap: {
    marginHorizontal: theme.spacing.screen,
    marginTop: theme.spacing.medium,
  },
  poster: {
    height: 190,
    borderRadius: theme.radius.large,
    overflow: 'hidden',
  },
  posterImage: {
    borderRadius: theme.radius.large,
  },
  posterOverlay: {
    flex: 1,
    justifyContent: 'flex-end',
    padding: theme.spacing.large,
    backgroundColor: 'rgba(41, 36, 42, 0.4)',
  },
  posterEyebrow: {
    color: theme.colors.lightGold,
    fontSize: theme.fontSize.caption,
    fontWeight: theme.fontWeight.bold,
    letterSpacing: theme.letterSpacing.medium,
  },
  posterTitle: {
    color: theme.colors.white,
    fontSize: theme.fontSize.xlarge,
    fontWeight: theme.fontWeight.black,
    marginTop: theme.spacing.small,
  },
  posterButton: {
    alignSelf: 'flex-start',
    backgroundColor: theme.colors.background,
    borderRadius: theme.radius.small,
    paddingVertical: theme.spacing.small,
    paddingHorizontal: theme.spacing.medium,
    marginTop: theme.spacing.medium,
  },
  posterButtonText: {
    color: theme.colors.primary,
    fontSize: theme.fontSize.small,
    fontWeight: theme.fontWeight.bold,
  },

  sectionHeader: {
    marginHorizontal: theme.spacing.screen,
    marginTop: theme.spacing.section,
    marginBottom: theme.spacing.medium,
  },
  sectionTitle: {
    color: theme.colors.text,
    fontSize: theme.fontSize.subheading,
    fontWeight: theme.fontWeight.bold,
  },
  sectionSubtitle: { marginTop: theme.spacing.tiny },
  categoryCard: {
    marginHorizontal: theme.spacing.screen,
    marginBottom: theme.spacing.medium,
    padding: theme.spacing.medium,
    borderRadius: theme.radius.medium,
  },
  categoryIconBox: {
    width: 59,
    height: 59,
    borderRadius: theme.radius.medium,
    backgroundColor: theme.colors.softPink,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  categoryImage: {
    width: '100%',
    height: '100%',
  },
  categoryInfo: {
    flex: 1,
    marginLeft: theme.spacing.medium,
  },
  categoryName: {
    color: theme.colors.primary,
    fontSize: theme.fontSize.large,
    fontWeight: theme.fontWeight.bold,
  },
  categoryDescription: { marginTop: theme.spacing.tiny },
  resultsTitle: {
    color: theme.colors.text,
    fontSize: theme.fontSize.large,
    fontWeight: theme.fontWeight.bold,
    marginHorizontal: theme.spacing.screen,
    marginTop: theme.spacing.small,
    marginBottom: theme.spacing.medium,
  },
  noResults: {
    marginHorizontal: theme.spacing.screen,
    padding: theme.spacing.large,
    alignItems: 'center',
  },
  noResultsText: {
    color: theme.colors.muted,
    fontSize: theme.fontSize.regular,
    textAlign: 'center',
  },
  noteBox: {
    marginHorizontal: theme.spacing.screen,
    marginTop: theme.spacing.medium,
    backgroundColor: theme.colors.lightPink,
    padding: theme.spacing.medium,
    borderRadius: theme.radius.medium,
  },
  noteTitle: {
    color: theme.colors.primary,
    fontSize: theme.fontSize.body,
    fontWeight: theme.fontWeight.bold,
  },
  noteText: {
    color: theme.colors.text,
    fontSize: theme.fontSize.small,
    marginTop: theme.spacing.small,
  },
});