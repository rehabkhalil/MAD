import React, { useEffect, useRef, useState } from 'react';
import { View, ScrollView, Animated, Easing, Dimensions, StyleSheet } from 'react-native';

import theme from '../styles/theme';

const BANNER_TEXT = '20% OFF on Shopping Above Rs. 1,200 — Available Till 20 October';
const SPEED = 10; // lower number = faster

export default function MovingBanner() {
  const translateX = useRef(new Animated.Value(0)).current;
  const [textWidth, setTextWidth] = useState(0);
  const screenWidth = Dimensions.get('window').width;

  useEffect(() => {
    if (!textWidth) return undefined;

    translateX.setValue(screenWidth);

    const loop = Animated.loop(
      Animated.timing(translateX, {
        toValue: -textWidth,
        duration: (textWidth + screenWidth) * SPEED,
        easing: Easing.linear,
        useNativeDriver: true,
      })
    );
    loop.start();

    return () => loop.stop();
  }, [textWidth, screenWidth, translateX]);

  return (
    <View style={styles.bar}>
      {/* A horizontal ScrollView gives the text unlimited width, so we can measure it */}
      <ScrollView horizontal scrollEnabled={false} showsHorizontalScrollIndicator={false}>
        <Animated.Text
          onLayout={(event) => setTextWidth(event.nativeEvent.layout.width)}
          style={[styles.text, { transform: [{ translateX }] }]}
        >
          {BANNER_TEXT}
        </Animated.Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  bar: {
    backgroundColor: '#8C2946',
    marginHorizontal: theme.spacing.screen,
    borderRadius: theme.radius.medium,
    paddingVertical: theme.spacing.medium,
    borderWidth: theme.borderWidth.thin,
    borderColor: theme.colors.gold,
    overflow: 'hidden',
  },
  text: {
    color: theme.colors.lightGold,
    fontSize: theme.fontSize.body,
    fontWeight: theme.fontWeight.bold,
  },
});