import React from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity } from 'react-native';

import theme from '../styles/theme';
import globalStyles from '../styles/globalStyles';

export default function ProductCard({ product, onPress }) {
  const title = product?.title || product?.name || 'Product';

  // Price is already in Rs. everywhere else in the app, so no conversion here.
  const price = Math.round(Number(product?.price || 0));

  const imageSource =
    typeof product?.image === 'string' ? { uri: product.image } : product?.image;

  return (
    <TouchableOpacity
      style={[globalStyles.card, styles.card]}
      onPress={onPress}
      activeOpacity={theme.opacity.pressed}
    >
      {product?.image ? (
        <Image source={imageSource} style={styles.image} resizeMode="contain" />
      ) : (
        <View style={[globalStyles.centered, styles.placeholder]}>
          <Text style={styles.placeholderIcon}>🛍️</Text>
        </View>
      )}

      <Text style={styles.name} numberOfLines={2}>
        {title}
      </Text>

      <Text style={styles.price}>Rs. {price.toLocaleString('en-PK')}</Text>

      <View style={styles.viewButton}>
        <Text style={styles.viewButtonText}>View Details →</Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    width: '48%',
    borderRadius: theme.radius.medium + 2,
    padding: theme.spacing.medium,
    marginBottom: theme.spacing.medium,
    elevation: 3,
  },
  image: {
    width: '100%',
    height: 130,
  },
  placeholder: {
    height: 130,
    backgroundColor: theme.colors.softPink,
    borderRadius: theme.radius.small,
  },
  placeholderIcon: { fontSize: theme.iconSize.large },
  name: {
    fontSize: theme.fontSize.compact,
    fontWeight: theme.fontWeight.medium,
    color: theme.colors.text,
    marginTop: theme.spacing.small,
    minHeight: 36,
  },
  price: {
    fontSize: theme.fontSize.body,
    fontWeight: theme.fontWeight.bold,
    color: theme.colors.primary,
    marginTop: theme.spacing.small,
  },
  viewButton: {
    backgroundColor: theme.colors.lightPink,
    padding: theme.spacing.small,
    borderRadius: theme.radius.small,
    alignItems: 'center',
    marginTop: theme.spacing.small,
  },
  viewButtonText: {
    color: theme.colors.primary,
    fontSize: theme.fontSize.small,
    fontWeight: theme.fontWeight.bold,
  },
});